//仅根据开发环境覆盖相应字段即可
const path = require('path');
const defaultPk = require('/data/tronbet_project/config/privateKey')
const pk = defaultPk.pk
let config_dev = {
    env: 'development',//开发环境设为development
    debug: true,//开发环境设为true
    app: {
        websocket_port: 8013,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true //开启日志
    },
    mysqlConfig: {
        db_host: 'localhost',
        db_port: '3306',
        db_name: 'tron_bet_wzc',
        db_user: 'root',
        db_pwd: '' 
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        // tron_url_full: 'https://api.shasta.trongrid.io', // https://testapi.trondapps.org:8090
        // tron_url_solidity: 'https://api.shasta.trongrid.io', // https://testapi.trondapps.org:8091
        // tron_url_event: 'https://api.shasta.trongrid.io/',
        // tron_url_full: 'http://10.4.24.126:8090', // https://testapi.trondapps.org:8090 ***
        // tron_url_solidity: 'http://10.4.24.126:8091', // https://testapi.trondapps.org:8091 ***
        // tron_url_event: 'https://api.trongrid.io/', 

        defaultPk: '',

        // back_tron_url_full: 'https://api.shasta.trongrid.io', // https://testapi.trondapps.org:8090 ***
        // back_tron_url_solidity: 'https://api.shasta.trongrid.io', // https://testapi.trondapps.org:8091 ***
        // back_tron_url_event: 'https://api.trongrid.io/', // ***
        tron_url_full: 'https://api.trongrid.io', // https://testapi.trondapps.org:8090 ***
        tron_url_solidity: 'https://api.trongrid.io', // https://testapi.trondapps.org:8091 ***
        tron_url_event: 'https://api.trongrid.io/', // ***

        back_tron_url_full: 'https://api.trongrid.io', // https://testapi.trondapps.org:8090 ***
        back_tron_url_solidity: 'https://api.trongrid.io', // https://testapi.trondapps.org:8091 ***
        back_tron_url_event: 'https://api.trongrid.io/', // ***
    },
    wheel: {
        // orcAddr : '416515c83499593c1d14e54dca1672d5c551722779', //随机数合约地址
        // moonAddr : '41df718cfb30fc168ca163f2a9ed44b3d329ba3504', //订单合约地址
        // logicAddr : '419cf6d5a6e0ff356e260432016f3afafec0235af9', //奖池合约地址

        logicAddr : '418115fae147740844dbd6c9816c613bc04d45274c', // 解决合约地址
        oracleAddr : '41469daae09764705e25835f617d9d7aaa74a6eb1a', //查询状态合约地址

        soloOrderAddr : '4107000d338303643a08d1d9295ba3526a3d421c6d',
        soloLogicAddr : '41b24b7936b27710f21cf3b170dcd5f30a44cc20e0',
        soloOracleAddr : '41ca6559b59efe24797dde84ab2c71de41515c37f3',

        startBlockNum : 5450000,
        
        WHEEL_MULTI : [50,5,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,5],

        APP_KEY: 'TRON_BET_WHEEL', //APP_KEY
        RANDOM_SALT_1: 'XfGNDsF0JInUDx!vfkZjttXp4jP4dc^%f', //随机数盐1
        RANDOM_SALT_2: '7y1@&jJvvOk87qbbbfJQ4UymhOVRI4kt', //随机数盐2
		RANDOM_SALT_3: '9N1#s1WTFc01S^#P%', //随机数盐3
		
		READY_DURATION : 20000, //等待下注事件ms
        MAX_LOSE : 500000, //每轮游戏最大赔付上限trx => 自动爆点
        MAX_EXIST_TIME : 1800000, //玩家创建房间最长持续时间
		MAX_BET : 1000, //单个玩家最大下注金额trx
		MAX_PAYOUT : 11000, //单个玩家最大赔付下注限制trx
		MAX_RATE : 9999, //最大爆点
		BROADCAST_INTERVAL_TS : 1000, //广播间隔ms
		broadcast_player_info_when_action : true, //是否玩家进出推送完整玩家信息列表
		check_key : false, //开启玩家数据验证
    }
}

module.exports = config_dev;