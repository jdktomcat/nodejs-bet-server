const fs = require('fs');
const path = require('path');
let defaultPk = null
let pk = null
try {
    defaultPk = require('/data/tronbet_project/config/privateKey')
    pk = defaultPk.pk  
} catch (error) {
    console.log('0000')
}

let config = {
    env: 'production',
    debug: false,
    app: {
        websocket_port: 8013,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true //开启日志
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_wzc',
        db_user: 'root',
        db_pwd: '' //!@Q3wa$ESZ
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        tron_url_full: 'http://192.169.81.142:8090', // https://testapi.trondapps.org:8090 ***
        tron_url_solidity: 'http://192.169.81.142:8091', // https://testapi.trondapps.org:8091 ***
        tron_url_event: 'https://api.trongrid.io/', // ***

        defaultPk: pk || '',

        back_tron_url_full: 'http://192.169.80.102:8090', // https://testapi.trondapps.org:8090 ***
        back_tron_url_solidity: 'http://192.169.80.102:8091',
        back_tron_url_event: 'https://api.trongrid.io/', // ***
    },
    wheel: {
        logicAddr : '413bc99b02c0b3d02475faa97a04e44543603ad2c6', // 解决合约地址
        oracleAddr : '41f1dd6a50563513b024a8c1a8257cadd66f42d16e', //查询状态合约地址

        soloOrderAddr : '4125fcfd3729801561b37f73189c98ab50341310c5',
        soloLogicAddr : '41a67fd02df7895a8bc70a0401db26ba0f2c3e28de',
        soloOracleAddr : '4150882bdd432f6d47a634a2c44b37f23ddb4115cf',

        startBlockNum : 10813882,

        WHEEL_MULTI : [50,5,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,5,2,5,2,3,2,3,2,3,2,5],
        MAX_EXIST_TIME : 1800000, //玩家创建房间最长持续时间

        APP_KEY: 'TRON_BET_WHEEL', //APP_KEY
        RANDOM_SALT_1: 'XfGNDsF0JIDDDx!vfkZjttXp4jP4dc^%f', //随机数盐1
        RANDOM_SALT_2: '7y1@&jJvvOk87qbbbfJQ4UymhOVRI4kt', //随机数盐2
                RANDOM_SALT_3: '9N1#s1WTFc01S^#P%', //随机数盐3

        BROADCAST_INTERVAL_TS : 1000, //广播间隔ms
        READY_DURATION : 20000,
                broadcast_player_info_when_action : true, //是否玩家进出推送完整玩家信息列表
                check_key : false, //开启玩家数据验证
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
