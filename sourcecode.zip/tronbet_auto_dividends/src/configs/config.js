const fs = require('fs');
const path = require('path');
let config = {
    env: 'production',
    debug: false,
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志
        init_ts: 1563850800, //初始截止时间戳 2019/7/23 11:00 NEW DICE
        duration: 86400, //每轮有效时间（秒） 86400
        time_out: 3600, //超时时间（秒）
        dividends_addr: "41b461e58a69c8fb8dec6e23888d5fcd743ab56938", //分红合约地址
        pool_addr: "411d0f4031f9e3eeeb727b10e462ab0e59ee06a2a6", //奖池合约地址
        min_pool_trx: 1, //最小分红奖池（单位TRX）
        min_interval_ts: 60, //发奖最小间隔时间(秒)
        pool_save_trx: 10000000, //奖池保留1000万TRX
        test_trx: 0,//测试要发送的TRX数量 0:按实际奖池数量发送 ***
        ignore_round_in_db: 0, //忽略数据库中不存在的轮次 ***
    },
    tronConfig: {
        node: {
            master: {
                url_full: 'http://192.169.81.106:8090',
                url_solidity: 'http://192.169.81.106:8091',
                url_event: 'https://api.trongrid.io/',
                defaultPk: ''
            },
            slave: {
                url_full: 'http://192.169.80.102:8090',
                url_solidity: 'http://192.169.80.102:8091',
                url_event: 'https://api.trongrid.io/',
                defaultPk: ''
            }
        },
        IGNORE_SOLIDITY_NODE_SCAN: true, //忽略检测静态节点状态
        SCAN_NODE_INTERVAL: 3100, //node 扫描间隔(ms)
        HTTP_TIME_OUT: 15000, //node http request 超时时间(ms)
    },
    redisConfig: {
        host: '127.0.0.1', //192.169.80.66
        port: 6379,
        db: 0,
        pwd: 'tronbet_201811'
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_wzc', // ***
        db_user: 'root',
        db_pwd: '' // *** localhost=!@Q3wa$ESZ lan:123456 wan:
    },
    support_trc10_list: {
        //TESTTWO:TSnHCFwsJxChEsV4mNoEPfA7qpzLcXzGjt
        // BTT: { tokenID: 1002072, tokenName: "BTT", decimail: 0, save_token: 1000000000000, poolAddr: '41b869101e67668c8ca3ff65fe744275f4dc5a7157', awardPK: '54B730AB3B20B2A20E0BC5F00067B60395DBA549F9D319777BDD7C76B229BAFD' }
        //TESTTWO:TKnAG9zcXMwxuKKRwYXecJT9sBrRPhmtCW //acc:TBv7igM3eVRsd144ayw7X3ecxsAdMQfBne
        BTT: { tokenID: 1002000, tokenName: "BTT", decimail: 6, save_token: 20000000, poolAddr: '41049909a380d589b9af76846280d3fcbeb67826f0', awardPK: '9053f12da788b539cedcfe4ed7dce4844364cd49764f76fa58ba2ad1b20b1ee3' }
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
