#!/bin/sh
npm run start