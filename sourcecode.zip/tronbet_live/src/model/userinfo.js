const db = require('../utils/dbUtil')
const _ = require('lodash')._

const dividendsDuration = 86400
const daystart = 18005

async function getUserBalance(addr) {
    console.log(addr)
    let sql = "select round(trx / 1000000, 3) as trx from live_user where addr = ?"
    let res = await db.exec(sql, [addr])
    console.log(res)
    if (!_.isEmpty(res)) {
        return res[0].trx
    }
    return null
}

async function getUserBalanceBySessionId(sessionId) {
    let sql = "select round(trx / 1000000, 3) as trx from live_user where sessionId = ?"
    let res = await db.exec(sql, [sessionId])
    console.log(res)
    if (!_.isEmpty(res)) {
        return res[0].trx
    }
    return null
}

async function userRegister(addr, nickName) {
    let sql = "insert into live_user(addr, nickName) values (?, ?)"
    let res = await db.exec(sql, [addr, nickName])
    return res
}

async function userLoginLog(addr) {
    let now = new Date().getTime()
    let sql = "insert into live_login_log(addr, ts) values(?,?)"
    let res = await db.exec(sql, [addr, now])
    return res
}

async function updateSessionId(addr, sessionId) {
    let now = new Date().getTime()
    let sql = "update live_user set sessionId = ?, loginTs = ? where addr = ?"
    let res = await db.exec(sql, [sessionId, now, addr])
    return res
}

async function updateUserKey(addr, userKey) {
    let now = new Date().getTime()
    let sql = "update live_user set userKey = ?, loginTs = ? where addr = ?"
    let res = await db.exec(sql, [userKey, now, addr])
    return res
}

async function userAction(AccountId, RoundId, EMGameId, GPGameId, GPId, TransactionId, RoundStatus, Amount, Device, txId, action, conn) {

    //update balance
    let updateSql = "update live_user set trx = trx - ? where addr = ?"
    if (action === 'result') {
        updateSql = "update live_user set trx = trx + ? where addr = ?"
    }
    await db.execTrans(updateSql, [Amount * 1e6, AccountId], conn)

    let now = new Date().getTime()
    let sql = "insert into live_action_log(addr, RoundId, EMGameId, GPGameId, GPId, TransactionId, RoundStatus, Amount, Device, txId, action, ts) values(?,?,?,?,?,?,?,?,?,?,?,?)"
    let res = await db.execTrans(sql, [AccountId, RoundId, EMGameId, GPGameId, GPId, '' + TransactionId, RoundStatus, Amount, Device, txId, action, now], conn)
    return res
}

async function userRollBack(AccountId, RoundId, EMGameId, GPGameId, GPId, TransactionId, RoundStatus, Amount, Device, txId, action, conn) {
    let updateSql = ''
    if (action == 'bet') {
        updateSql = "update live_user set trx = trx + ? where addr = ?"
    } else if (action == 'result') {
        updateSql = "update live_user set trx = trx - ? where addr = ?"
    }
    await db.execTrans(updateSql, [Amount * 1e6, AccountId], conn)

    let updateStatusSql = "update live_action_log set txStatus = txStatus - 1 where addr = ? and TransactionId = ?"
    await db.execTrans(updateStatusSql, [AccountId, '' + TransactionId], conn)

    let now = new Date().getTime()
    console.log({ AccountId, RoundId, EMGameId, GPGameId, GPId, TransactionId, RoundStatus, Amount, Device, txId, action })
    let sql = "insert into live_action_log(addr, RoundId, EMGameId, GPGameId, GPId, TransactionId, RoundStatus, Amount, Device, txId, action, ts) values(?,?,?,?,?,?,?,?,?,?,?,?)"
    let res = await db.execTrans(sql, [AccountId, RoundId, EMGameId, GPGameId, GPId, 'rb' + TransactionId, RoundStatus, Amount, Device, txId, action, now], conn)
    return res
}

async function getTransactionById(TransactionId) {
    let sql = "select * from live_action_log where TransactionId = ?"
    return await db.exec(sql, ['' + TransactionId])
}

async function withdraw(addr, amount, orderId, conn) {
    let sql = "update live_user set trx = trx - ? where addr = ?"
    let res1 = await db.execTrans(sql, [amount, addr], conn)

    let now = new Date().getTime()
    let logSql = "insert into live_withdraw_log(orderId, addr, amount, startTs) values (?,?,?,?)"
    let logres = await db.execTrans(logSql, [orderId, addr, amount, now], conn)
    return logres
}

async function finishedWithdrawLog(addr, txId, orderId) {
    let sql = "update live_withdraw_log set txId = ?, endTs = ? where orderId = ? and addr = ?"
    let now = new Date().getTime()
    let res = await db.exec(sql, [txId, now, orderId, addr])
    return res
}

async function findTodayWithdrawTimes(addr) {
    let now = new Date().getTime()
    let zeroTime = 1551283200000
    let todayStime = now - ((now - zeroTime) % 86400000)
    let sql = "select count(1) cnt from live_withdraw_log where addr = ? and startTs >= ?"
    let res = await db.exec(sql, [addr, todayStime])
    return res[0].cnt
}

async function getAccountBySessionId(sessionId) {
    let sql = "select * from live_user where sessionId = ?"
    let res = await db.exec(sql, [sessionId])
    return res
}

async function getUserActionLog(adrr, actionId) {
    let sql = "select * from live_action_log where addr = ? and actionId = ?"
    let res = await db.exec(sql, [addr, actionId])
    return res
}

async function generateFreespins(addr, issuseId, exprTs, num, status) {
    let sql = "insert into live_freespins(addr, issuseId, exprTs, num, status, ts) values(?,?,?,?,?,?)"
    let now = new Date().getTime()
    let res = await db.exec(sql, [addr, issuseId, exprTs, num, status, now])
    return res
}

async function cancelFreespins(issuseId) {
    let sql = "update live_freespins set status = 'canceled', ts = ? where issuseId = ?"
    let now = new Date().getTime()
    let res = await db.exec(sql, [now, issuseId])
    return res
}


async function getUserIdByIssuseId(issuseId) {
    let sql = "select addr from live_freespins where issuseId = ?"
    let res = await db.exec(sql, [issuseId])
    return res
}

async function getSportsProfit(startTs, endTs) {
    let sql = "select sum(amount / 1000000 - win / 1000000) amount from sports_transaction_log where ts >= ? and ts < ? and status >= 50"
    let res = await db.exec(sql, [startTs, endTs])
    if (_.isEmpty(res)) return 0
    return res[0].amount || 0
}

async function getRealTimeProfitAmount(ts) {
    let startTs = (Math.floor(ts / dividendsDuration)) * dividendsDuration * 1000
    let endTs = ts * 1000
    let sql = "select sum(Amount) amount from tron_live.live_action_log where ts >= ? and ts < ? and action = ? and txStatus = 1"
    let betAmount = await db.exec(sql, [startTs, endTs * 10, 'bet'])
    let resultAmount = await db.exec(sql, [startTs, endTs * 10, 'result'])
    let soportsRealTimeProfit = await getSportsProfit(startTs, endTs * 10)

    let lastDay = Math.floor(ts / dividendsDuration) - 1
    if (lastDay >= 0) {
        let hasYestodayProfit = await hasLastDayProfit(lastDay)
        if (!hasYestodayProfit) {
            // 插入
            
            let lastBetAmount = await db.exec(sql, [startTs - 86400000, startTs, 'bet'])
            let lastResultAmount = await db.exec(sql, [startTs - 86400000, startTs, 'result'])

            if (_.isEmpty(lastBetAmount)) {
                lastBetAmount = 0
            } else {
                lastBetAmount = lastBetAmount[0].amount || 0
            }

            if (_.isEmpty(lastResultAmount)) {
                lastResultAmount = 0
            } else {
                lastResultAmount = lastResultAmount[0].amount || 0
            }

            let sportsProfitAmount = await getSportsProfit(startTs - 86400000, startTs)

            console.log('=====startTs,lastBetAmount,lastResultAmount, sportsProfitAmount=====',startTs,lastBetAmount,lastResultAmount, sportsProfitAmount)
            await insertLastDay(lastDay, lastBetAmount + sportsProfitAmount - lastResultAmount)
        }
    }

    let lastTotalProfit = await getHistDaysProfit()

    if (!_.isEmpty(betAmount)) {
        betAmount = betAmount[0].amount || 0
    } else {
        betAmount = 0
    }

    if (!_.isEmpty(resultAmount)) {
        resultAmount = resultAmount[0].amount || 0
    } else {
        resultAmount = 0
    }

    // console.log('lastTotalProfit,totalDividends ++++>', lastTotalProfit,totalDividends)
    let totalDividends = await getDividendsAmount()
    console.log('lastTotalProfit - totalDividends + betAmount - resultAmount, soportsRealTimeProfit ====>', Number(lastTotalProfit),totalDividends,betAmount,resultAmount, soportsRealTimeProfit)

    return Number(lastTotalProfit) - Number(totalDividends) +  Number(betAmount) - Number(resultAmount) + Number(soportsRealTimeProfit)
}
async function insertLastDay(day, amount) {
    let sql = "insert into live_profit_log(days, profit) values(?,?)"
    let res = await db.exec(sql, [day, amount * 1e6])
    return res
}

async function hasLastDayProfit(day) {
    let sql = "select profit from live_profit_log where days = ?"
    let res = await db.exec(sql, [day])
    if (_.isEmpty(res)) return false
    return true
}

async function getHistDaysProfit() {
    let sql = "select sum(profit / 1000000) profit from live_profit_log"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].profit || 0
}

async function getDividendsAmount() {
    let sql = "select sum(total_trx / 1000000 + rank_trx / 1000000) trx from live_div_info"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].trx || 0
}

async function getUserWithDrawStatus(addr, orderId) {
    let sql = "select startTs from live_withdraw_log where orderId = ? and addr = ?"
    let res = await db.exec(sql, [orderId, addr])
    return res
}

async function getAmountRankData(round) {
    let sql = "select addr, amount / 1000000 amount from live_bet_info where round = ? order by amount desc limit 20"
    let res = await db.exec(sql, [round])
    return res
}

async function getProfitRankData(round) {
    let sql = "select addr, win / 1000000 amount from live_bet_info where round = ? order by win desc limit 20"
    let res = await db.exec(sql, [round])
    return res
}

async function getRankBonus(startTs) {
    let sql = "select sum(rank_trx / 1000000) amount from live_div_info where send_ts >= ?"
    let res = await db.exec(sql, [startTs])
    if (_.isEmpty(res)) return 0
    return res[0].amount || 0
}

async function maxAmountRewardRound() {
    let sql = "select max(round) maxRound from live_amount_rank_log"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].maxRound || 0
}

async function maxPayoutRewardRound() {
    let sql = "select max(round) maxRound from live_payout_rank_log"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].maxRound || 0
}

async function addAmountRankWardLog(round, addr, amount, wardAmount, ts, conn) {
    console.log('------round, addr, amount, wardAmount, ts, ------', round, addr, amount, wardAmount, ts)
    let sql = "insert into live_amount_rank_log(round, addr, amount, wardAmount, ts) values(?,?,?,?,?)"
    let res = await db.execTrans(sql, [round, addr, amount, wardAmount, ts], conn)
    return res
}

async function addPayoutRankWardLog(round, addr, amount, wardAmount, ts, conn) {
    console.log('------round, addr, amount, wardAmount, ts, ------', round, addr, amount, wardAmount, ts)
    let sql = "insert into live_payout_rank_log(round, addr, amount, wardAmount, ts) values(?,?,?,?,?)"
    let res = await db.execTrans(sql, [round, addr, amount, wardAmount, ts], conn)
    return res
}

async function updateTxidToAmountRankWardLog(round, addr, txId) {
    let sql = "update live_amount_rank_log set txId = ? where round = ? and addr = ?"
    let res = await db.exec(sql, [txId, round, addr])
    return res
}

async function updateTxidToPayoutRankWardLog(round, addr, txId) {
    let sql = "update live_payout_rank_log set txId = ? where round = ? and addr = ?"
    let res = await db.exec(sql, [txId, round, addr])
    return res
}

async function getLastDividends(startTs) {
    let sql = "select total_trx * 0.15 trx, send_ts ts, 'LIVE' types from tron_live.live_div_info where send_ts >= ? union all select total_trx * 0.15 trx, send_ts ts, 'RAKE' types from tronbet_poker_log.rake_div_info where send_ts >=?"
    let res = await db.exec(sql, [startTs, startTs])
    return res
}

async function getFreespinNum(addr) {
    let sql = 'select fsNum from live_freespin_user where addr = ?'
    let res = await db.exec(sql, [addr])
    if(_.isEmpty(res)) return 0
    return res[0].fsNum
}

async function addFreeSpinUser(addr,nickName, userId, num) {
    let num = await getFreespinNum(addr)
    if (num >= 20) return
    let sql = "insert into live_freespin_user(addr, nickName, emUserId, fsNum) values(?,?,?,?) on DUPLICATE KEY UPDATE fsNum = fsNum + ?"
    let res = await db.exec(sql, [addr, nickName, userId, num, num])
    return res
}

async function addFressSpinLog(addr, orderId, endTs, ts) {
    let sql = 'insert into live_freespin_log(addr, orderId, endTs, ts) values(?,?,?,?)'
    let res = await db.exec(sql, [addr, orderId, endTs, ts])
    return res
}

module.exports = {
    getUserBalance,
    userRegister,
    userLoginLog,
    updateSessionId,
    getUserBalanceBySessionId,
    userAction,
    userRollBack,
    withdraw,
    finishedWithdrawLog,
    findTodayWithdrawTimes,
    getAccountBySessionId,
    getUserActionLog,
    generateFreespins,
    cancelFreespins,
    getUserIdByIssuseId,
    getTransactionById,
    getRealTimeProfitAmount,
    getUserWithDrawStatus,
    getAmountRankData,
    getProfitRankData,
    getRankBonus,
    maxAmountRewardRound,
    maxPayoutRewardRound,
    addAmountRankWardLog,
    addPayoutRankWardLog,
    updateTxidToAmountRankWardLog,
    updateTxidToPayoutRankWardLog,
    getLastDividends,
    updateUserKey
}