const tronUtils = require('../utils/tronUtil')
const axios = require('axios')
const log4js = require('../configs/log4js_config')
const loggerDefault = log4js.getLogger('print')
const {app, tronConfig} = require('../configs/config')
const redisUtils = require('../utils/redisUtil')
const usermodel = require('../model/userinfo')
const dbUtil = require('../utils/dbUtil')
const TronWeb = require('tronweb')
const evnets = require('events')
const common = require('../utils/common')
const _ = require('lodash')._
const userEvent = new evnets.EventEmitter()

const redisUserKeyPrefix = 'live:user:'

async function login(ctx) {

    let result = {
        code : 0,
        info : '',
        data :null
    }

    let params = ctx.request.body
    let signature = params.sign
    let addr = params.addr
    
    if (!TronWeb.isAddress(addr) || signature == null) {
        result.info = 'tron address error!!!'
        result.code = 1002
        ctx.body = result
        return
    }

    //签名校验
    let signResult = await tronUtils.verifySignature(signature, addr)
    if (!signResult) {
        result.info = 'sign verify failed!!!!!!!!!'
        ctx.body = result
        return
    }

    let _name = await redisUtils.hget(redisUserKeyPrefix + addr, 'name')
    if (!_name) {
        _name = await tronUtils.getAccountName(addr)
        if (_name == addr) {
            console.log('no nickName found')
        } else {
            await redisUtils.hset(redisUserKeyPrefix + addr, 'name', _name)
        }
    }

    //查询余额, 没有查询到
    let _balance = await usermodel.getUserBalance(addr)
    if(_balance == null) {
        await usermodel.userRegister(addr, _name == addr ? '' : _name)
        _balance = 0
    }

    //登录日志记录
    await usermodel.userLoginLog(addr)

    let sessionId = common.getRandomSeed(48)

    try {
        await usermodel.updateSessionId(addr, sessionId)
    } catch (error) {
        sessionId = common.getRandomSeed(48)
        await usermodel.updateSessionId(addr, sessionId)
    }
    await redisUtils.hset(redisUserKeyPrefix + addr, 'sessionId', sessionId)

    let data = await getRemoteUserInfo(addr)
	
	await redisUtils.hset(redisUserKeyPrefix + addr, 'lv', data.data.lv)
	await redisUtils.hset(redisUserKeyPrefix + addr, 'img', data.data.img)

    let lanuchOptions = {
        sessionId : sessionId,
        launchUrl : '',
        balance : _balance,
        lv : data.data.lv,
        name : _name,
        img : data.data.img
        // name :
    }
    result.data = lanuchOptions
    ctx.body = result
    return
}

async function userBalance(ctx) {

    let result = {
        code : 0,
        info : '',
        data :null
    }

    let params = ctx.request.body
    let addr = params.addr
    
    if (!TronWeb.isAddress(addr)) {
        result.info = 'tron address error!!!'
        result.code = 1002
        ctx.body = result
        return
    }
    let _balance = await usermodel.getUserBalance(addr)
    if(_balance == null) {
        _balance = 0
    }

    let _name = await redisUtils.hget(redisUserKeyPrefix + addr, 'name')
    if (!_name) {
        _name = addr
    }

	let lv = await redisUtils.hget(redisUserKeyPrefix + addr, 'lv')
	let img = await redisUtils.hget(redisUserKeyPrefix + addr, 'img')
	if (!img) {
		let data = await getRemoteUserInfo(addr)
		await redisUtils.hset(redisUserKeyPrefix + addr, 'lv', data.data.lv)
		await redisUtils.hset(redisUserKeyPrefix + addr, 'img', data.data.img)
		lv = data.data.lv
		img = data.data.img
	}

    result.data = {
        balance : _balance,
        name : _name,
        lv : lv,
        img : img
    }

    ctx.body = result
}

async function getRemoteUserInfo(addr) {
    let result = {data : {}}
    try {
        let {data} = await axios.get('https://backendapi.tronbet.io/beter/userOverViewInfo?addr=' + addr)
        result = data
    } catch (error) {
        console.log(error)
    }

    return result
    
}


async function withdraw(ctx) {
    
    let result = {
        code : 1001,
        info : '',
        data :null
    }

    let params = ctx.request.body

    let signature = params.sign
    let addr = params.addr
    let amount = Math.floor(params.amount * 1e6)

    console.log(signature, addr, amount)

    if (isNaN(amount) || amount < 1) {
        result.code = 1010
        result.info = 'amount error'
        ctx.body = result
        return
    }
    
    if (!TronWeb.isAddress(addr) || signature == null) {
        result.info = 'tron address error!!!'
        ctx.body = result
        return
    }

    //签名校验
    let signResult = await tronUtils.verifySignature(signature, addr)
    if (!signResult) {
        result.info = 'sign verify failed!!!!!!!!!'
        ctx.body = result
        return
    }

    //每天提现次数限制
    let todayWithdrawTimes = await usermodel.findTodayWithdrawTimes(addr)
    console.log(todayWithdrawTimes, app.withdrawMaxTimes)
    if(todayWithdrawTimes >= app.withdrawMaxTimes) {
        result.code = 1009
        result.info = 'withdraw reached max times'
        ctx.body = result
        return
    }

    // 每次提现最大额度
    if (amount >= app.withdrawMaxAmount) {
        result.code = 1008
        result.info = 'withdraw reached max amount'
        ctx.body = result
        return
    }

    let wOrderId = common.getRandomSeed(64)

    console.log('wOrderId-------', wOrderId)
    let balance = await usermodel.getUserBalance(addr)
    balance = balance || 0

    if (balance * 1e6 < amount) {
        result.code = 1010
        result.info = 'amount error'
        ctx.body = result
        return
    }

    let conn = null
    try {
        // 1 扣除余额
        conn = await dbUtil.getConnection()
        conn.beginTransaction()
        let res = await usermodel.withdraw(addr, amount, wOrderId, conn)
        conn.commit()
        
        try {
            userEvent.emit('transferTrx', addr, amount, wOrderId)
        } catch (error) {
            loggerDefault.error(error)
        }
    } catch (error) {
        conn.rollback()
        loggerDefault.error(error)
        ctx.body = 'amount not enough'
    } finally {
        if (conn) conn.release()
    }

    result.code = 0
    result.data = {balance : balance - amount / 1e6}
    ctx.body = result
}

userEvent.on('transferTrx', (addr, amount, wOrderId) => {
    // 2 尝试转trx给玩家
    let timer = setTimeout(async () => {
        clearTimeout(timer)
        try {

            let status = usermodel.getUserWithDrawStatus(wOrderId, addr)

            if (!_.isEmpty(status)) {
                console.log('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')
            }

            console.log('addr, amount, wOrderId----------------',addr, amount, wOrderId)
            let result = await tronUtils.tronExec(tronConfig.withdrawAddr, 'Withdraw(address,uint256,uint256)', 5e6, 0, [{type : 'address', value : addr},
                 {type : 'uint256', value : amount},
                 {type : 'uint256', value : '0x' + wOrderId}])
            console.log(result)
            if (result.result  !=  true) {
                userEvent.emit('transferTrx', addr, amount, wOrderId)
            } else {
                let maxConfirmTimes = 5 //20 seconds
                userEvent.emit('trxConfirm', addr, amount, wOrderId, result.transaction.txID, maxConfirmTimes)
            }
            
            // let _now = new Date().getTime()
        } catch (error) {
            loggerDefault.error(error)
            await common.sleep(2000) //延迟两秒在尝试
            userEvent.emit('transferTrx', addr, amount, wOrderId)
        }
    }, 300)
})

//trx 确认
userEvent.on('trxConfirm', (addr, amount, wOrderId, txId, tryTimes) => {
    loggerDefault.info('-----------trxConfirm----------')
    let timer = setTimeout(async () => {
        clearTimeout(timer);
        try {
            if (!tryTimes || tryTimes <= 0) {
                loggerDefault.error('tx confirmed max times', {addr, amount, wOrderId, txId})
                userEvent.emit('transferTrx', addr, amount, wOrderId)
                return
            }
            let confirmResult = await tronUtils.isTxSuccesssed(txId)
            if(!confirmResult) {
                loggerDefault.info('confirm txid', {addr, amount, wOrderId, txId}, tryTimes - 1)
                userEvent.emit('trxConfirm', addr, amount, wOrderId, txId, tryTimes - 1)
                return
            }
            let res1 = await usermodel.finishedWithdrawLog(addr, txId, wOrderId)
        } catch (error) {
            loggerDefault.error(error)
            // userEvent.emit('transferTrx', addr, amount, wOrderId, txId)
        }
    }, 10000);
})

async function games(ctx) {
    let result = {
        code : 0,
        info : '',
    }
    let data = await redisUtils.hget('tronlive:gamelist', 'games')
    try {
        data = JSON.parse(data)
    } catch (error) {
        data = []
    }
    result.data = data
    ctx.body = result
}

async function verifySession(ctx) {

    let result = {
        code : 0,
        info : '',
        data :null
    }

    let params = ctx.request.body
    let addr  = params.addr
    let sessionId = params.session_id
    if (!TronWeb.isAddress(addr) || sessionId == null) {
        result.info = 'tron address error!!!'
        result.code = 1012
        ctx.body = result
        return
    }

    let res = await usermodel.getAccountBySessionId(sessionId)
    if (_.isEmpty(res)) {
        result.info = 'tron address error!!'
        result.code = 1012
        ctx.body = result
        return
    }

    if (res[0].addr != addr) {
        result.info = 'session Id error!!!'
        result.code = 1015
        ctx.body = result
        return
    }

    result.info = 'success'
    result.code = 0
    ctx.body = result
    return
}

async function realTimeProfit(ctx) {
    let result = {
        code : 0,
        info : '',
        data :null
    }

    let profit = await redisUtils.hget('tronlive:realtime', 'profit')
    if (!profit) {
        profit = 0
    }
    // let now = Math.floor(new Date().getTime() / 1000)
    // let profit = await usermodel.getRealTimeProfitAmount(now)
    result.data = {amount : Math.floor(profit * 0.97)}
    ctx.body = result
}

async function getAddLiveTrxToAntePool(ctx) {
    let result = {
        code : 0,
        info : '',
        data :null
    }
    let res = await redisUtils.hget('tronlive:lastdivs', 'list')
    if(!res) {
        result.data = []
    } else {
        result.data = JSON.parse(res)
    }
    ctx.body = result
}

async function getJackPotDetail(ctx) {
    let result = {
        errno : 0,
        info : '',
        data :null
    }
    let res = await redisUtils.hget('tronlive:bonus', 'jackpot')
    if(!res) {
        result.data = []
    } else {
        result.data = JSON.parse(res)
    }
    ctx.body = result
}



async function getKey(ctx) {

    let result = {
        code : 0,
        info : '',
        data :null
    }

    let params = ctx.request.body
    let signature = params.sign
    let addr = params.addr
    
    if (!TronWeb.isAddress(addr) || signature == null) {
        result.info = 'tron address error!!!'
        result.code = 1002
        ctx.body = result
        return
    }

    //签名校验
    let signResult = await tronUtils.verifySignature(signature, addr)
    if (!signResult) {
        result.info = 'sign verify failed!!!!!!!!!'
        ctx.body = result
        return
    }

    let _name = await redisUtils.hget(redisUserKeyPrefix + addr, 'name')
    if (!_name) {
        _name = await tronUtils.getAccountName(addr)
        if (_name == addr) {
            console.log('no nickName found')
        } else {
            await redisUtils.hset(redisUserKeyPrefix + addr, 'name', _name)
        }
    }

    //查询余额, 没有查询到
    let _balance = await usermodel.getUserBalance(addr)
    if(_balance == null) {
        await usermodel.userRegister(addr, _name == addr ? '' : _name)
        _balance = 0
    }

    //登录日志记录
    await usermodel.userLoginLog(addr)

    let key = common.getRandomSeed(48)

    try {
        await usermodel.updateUserKey(addr, key)
    } catch (error) {
        key = common.getRandomSeed(48)
        await usermodel.updateUserKey(addr, key)
    }
    await redisUtils.hset(redisUserKeyPrefix + addr, 'userKey', key)

    let data = await getRemoteUserInfo(addr)
	
	await redisUtils.hset(redisUserKeyPrefix + addr, 'lv', data.data.lv)
	await redisUtils.hset(redisUserKeyPrefix + addr, 'img', data.data.img)

    let lanuchOptions = {
        userKey: key,
        balance: _balance,
        lv: data.data.lv,
        name: _name,
        img: data.data.img
    }
    result.data = lanuchOptions
    ctx.body = result
    return
}

module.exports = {
    login,
    withdraw,
    userBalance,
    games,
    verifySession,
    realTimeProfit,
    getRemoteUserInfo,
    getAddLiveTrxToAntePool,
    getJackPotDetail,
    getKey,
}