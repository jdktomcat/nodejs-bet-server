const axios = require('axios')

let GAMES = {
    slots : [],
    balckjack: [],
    baccarat : [],
    roulette : [],
    poker : [],
}

let jsonFeedsUrl = 'http://casino2.stage.everymatrix.com/jsonFeeds/mix/tronbet?types='
jsonFeedsUrl = 'http://casino.everymatrix.com/jsonFeeds/mix/tronbet?types='

const GameSWhilte = [
    'Stoner Joker 5',
    'Trump It Deluxe',
    'Power of Asia',
    'Wild Rodeo',
    'Evil Genotype',
    'Fortunes of the Jungle',
    'Unlikely Royals',
    'Hera\'s Gold',
    'Reel Angels',
    'Victorious Vikings',
    'Kailash Mystery',
    'God\'s Temple',
    'Thunder Zeus',
    'African Spirit',
    'Gnomes\' Gems',
    '12 Animals',
    '15 Golden Eggs',
    'Diego Fortune',
    'Crazy Gems',
    'Poisoned Apple',
    'Book of Sun',
    'Zodiac',
    'Secret of Nefertiti 2',
    'Nord\'s War',
    'Goddess of the Moon',
    'Fortune Multiplier',
    'The Witch',
    'Age of Caesar',
    'Ella\'s Riches',
    'Nefertiti\'s Gold',
    "Pharaoh\'s Empire",
    'Jade Valley',
    'Jewel Bang',
    'Mistress of Amazon',
    'Fairy Forest',
    'Fruity Sevens',
    'Crazy Jellies',
    // 'Yumi And Kaori',
    'Snow Wild',
    // 'Shanghai Respins',
    'Dragon\'s Castle',
    'Sumo Showdown',
    'Lucky Cat',
    'Sakura Wind',
    'Power of Gods',
    'Magical Wolf',
    'Legend of Atlantis',
    'Crocoman',
    'Lucky Money',
    'Fiery Planet',
    'Lucky Dolphin',
    'Cinderella',
    'Richy Witchy',
    'Aztec Temple',
    'Magical Mirror',
    'Mega Drago',
    'Bison Trail',
    'Great Ocean',
    'Book of Egypt',
    'Neon Classic',
    'Triple Dragon',
    'Cleos Gold',
    'Power of Poseidon',
]

const TableGames = [
    'Blackjack PP',
    'Blackjack Vip',
    'Blackjack Classic',
    'Blackjack',
    'Roulette',
    'Baccarat Mini',
    'Baccarat',
    'Baccarat VIP',
    'Texas Holdem',
    'Sic Bo',
    'Russian Poker',
]


const liveGames = [
    8851533347, //Baccarat A
    8852533388, //Baccarat B
    8853533392, //Baccarat C
    8854533428, //Baccarat D
    8848533343, //Roulette A
    8849533393, //Roulette B
    15487000526, // Dragon Tiger
    15488075615, // 69 Casino OTT Roulette
    15488056709, //69 Casino OTT Roulette
    15488056116, //Oracle Casino OTT Roulette
    15488084739, //PortomasoCasino OTTRoulette
    15488088170, //Palace Casino OTT Roulette
    15486029436, //BaccaratQueenco 1
    15486042485, //BaccaratQueenco 2
    15486027407, //BaccaratQueenco 3
    15486004937, //BaccaratQueenco
    16176094210, //Baccarat Super 6
    16175095699, //Baccarat Knock Out
    8680064229,  //Blackjack III
    8680034816, //Blackjack C
    8680046077, //Unlimited Blackjack - Auto Split!
    13559095411, //Dice Duel
    13558023530, //Lucky 6
    8680094360,  //European (EGS/Belgium) lobby
    8680011115, //Eastern Europe lobby
    8680071453, //Latin America lobby
    8682079012, //Roulette RU
    8680036743, //Blackjack II
    8680087554, //Blackjack I
    11149092816, //Automatic Roulette
    11147055805, //Casino Hold'em
    8680062024, //Baltic Studio Lobby
    8680024863, //Blackjack 1
    8680044562, //Blackjack 2
    8680015637, //Blackjack 3
    8680000633, // Blackjack 4
    8680022084, // Blackjack 5
    8682048991, //Roulette TR
    10041013128, //War of Bets
    9204076879, //Wheel of Fortune
    9202085855, //Keno
    8960046285, //Bet on Baccarat
    8682034337, //Roulette A
    8681025076, //Baccarat A
    8680020120, //Blackjack A
    8682050355, //Roulette B
    8681040891, //Baccarat B
    8680058404, //Blackjack B
    8687095740, //Bet on Poker
    8688059906, //Dice
    8689095592, //Lotto 5 - 36
    8690041171, //Lotto 7 - 42
    8683038478, //Lotto 6 - 49
]


function sortbyLiveGames(firstEl, secondEl) {
    
    let index1 = liveGames.indexOf(firstEl.id)
    let index2 = liveGames.indexOf(secondEl.id)
    console.log(firstEl.id, index1, secondEl.id, index2)
    if (index1 > index2) return 1
    if (index1 == index2) return 0
    return -1
}

async function getAllGamesFromEM() {
    let result = ''
    let {data} = await axios.get(jsonFeedsUrl + 'Game')
    // console.log(data)
    result = data

    let tablegames = await axios.get(jsonFeedsUrl + 'table')
    return result + tablegames.data
}

function isInWhiteLists(gameName) {
    let whiteGames = [...GameSWhilte, ...TableGames, ...liveGames]
    for (let one of whiteGames) {
        if(one == gameName) return true
    }
    return false
}

async function getIndexOfGame(gameName) {
    let index = 0
    for (let one of GameSWhilte) {
        if(one == gameName) return index
        index++
    }

    return index
}

async function getIndexOfLiveCasino(gameName) {
    let index = 0
    for (let one of liveGames) {
        if(one == gameName) return index
        index++
    }

    return index
}

async function getIndexOfTableGames(gameName) {
    let index = 0
    for (let one of TableGames) {
        if(one == gameName) return index
        index++
    }

    return index
}

async function parseGames() {
    let data = await getAllGamesFromEM()
    // console.log(games)
    // games = JSON.parse(games)
    // for (let one in games) {
    //     console.log(one)
    // }

    let games = data.split('\n')
    let slots = []
    let balckjack = []
    let baccarat  = []
    let roulette  = []
    let lottery = []
    let livePoker = []
    let holdem = []
    let poker  = []
    for (let one of games) {
        if (one == "") continue
        let gameInfo = null
        try {
            gameInfo = JSON.parse(one)
        } catch (error) {
            continue
        }
        if (gameInfo.data == null) continue
        let datainfo = gameInfo.data
        
        let minBet = 0
        let maxBet = 0

        if (datainfo.property.limits) {
            let mm = datainfo.property.limits['TRX'] || datainfo.property.limits['EUR']
            minBet = mm.min
            maxBet = mm.max
        }

        if (datainfo.openingTime && datainfo.openingTime.is24HoursOpen == false) {
            let startTtime = datainfo.openingTime.startTime
            let endTime = datainfo.openingTime.endTime
            let nowHours = new Date().getUTCHours()
            if (nowHours < startTtime && nowHours > endTime) {
                continue
            }
        }

        let tmp = {
            launchUrl : datainfo.url,
            gameName : datainfo.presentation.shortName["*"],
            // iconFormat : datainfo.presentation.iconFormat["*"],
            // logo : datainfo.presentation.logo["*"],
            thumbnail :  datainfo.presentation.thumbnail["*"],
            popularity: datainfo.popularity,
            terminal : datainfo.property.terminal,
            id : datainfo.id,
            openTime : datainfo.openingTime,
            minBet,
            maxBet,
        }

        if (!isInWhiteLists(datainfo.presentation.shortName["*"]) && !isInWhiteLists(datainfo.id)) continue

        // let vendor = datainfo.vendor
        // if (vendor !== 'Platipus') {
        //     continue
        // }

        let categories = datainfo.category == null ? datainfo.categories : [datainfo.category]
        for (let cate of categories) {
            console.log(cate)
            cate = cate.toUpperCase()
            let SoltReg =  /.*SLOTS.*/
            if (cate.match(SoltReg)) {
                if (tmp.gameName) {
                    slots[await getIndexOfGame(tmp.gameName)] = tmp
                }
            }

            let balckReg =  /.*BLACKJACK.*/
            if (cate.match(balckReg)) {
                balckjack.push(tmp)
            }

            let baccaratReg =  /.*BACCARAT.*/
            if (cate.match(baccaratReg)) {
                baccarat.push(tmp)
            }

            let rouletteReg =  /.*ROULETTE.*/
            if (cate.match(rouletteReg)) {
                roulette.push(tmp)
            }

            let lottryReg =  /.*LOTTERY.*/
            if (cate.match(lottryReg)) {
                lottery.push(tmp)
            }

            let livePokerReg =  /.*POKER.*/
            if (cate.match(livePokerReg)) {
                livePoker.push(tmp)
            }

            let holdEmReg =  /.*HOLDEM.*/
            if (cate.match(holdEmReg)) {
                livePoker.push(tmp)
            }

            let pokerReg =  /.*TABLEGAMES.*/
            if (cate.match(pokerReg)) {
                if (tmp.gameName) {
                    poker[await getIndexOfTableGames(tmp.gameName)] = tmp
                }
            }
        }
    }

    holdem.sort(sortbyLiveGames)
    balckjack.sort(sortbyLiveGames)
    baccarat.sort(sortbyLiveGames)
    roulette.sort(sortbyLiveGames)
    lottery.sort(sortbyLiveGames)
    livePoker.sort(sortbyLiveGames)
    
    return {
        slots,
        balckjackt : balckjack,
        baccaratt : baccarat,
        roulettet : roulette,
        lotteryt : lottery,
        livePokert : livePoker,
        holdem : holdem,
        balckjack : [],
        baccarat : [],
        roulette : [],
        poker,
    }
}


module.exports = {
    parseGames,
}