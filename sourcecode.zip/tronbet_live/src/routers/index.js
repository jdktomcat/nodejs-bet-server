const router = require('koa-router')()

const action = require('./action')
const payment = require('./payment')
const user = require('./user')
// const freespins = require('./freespins')
const rank = require('./rank')

router.use('/', action.routes(), action.allowedMethods())
// router.use('/freespins', freespins.routes(), freespins.allowedMethods())
router.use('/payment', payment.routes(), payment.allowedMethods())
router.use('/user', user.routes(), user.allowedMethods())
router.use('/rank', rank.routes(), rank.allowedMethods())

module.exports = router