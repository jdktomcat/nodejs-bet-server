const fs = require('fs');
const path = require('path');
let defaultPK = null;
try {
    defaultPK = require('/data/tronbet_project/config/privateKey').pk;
} catch (error) {
    console.log("using app pk");
    defaultPK = '';
}

let config = {
    env: 'dev',
    debug: false,
    app: {
        http_port : 9015,
        websocket_port: 9012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志,
        withdrawMaxTimes : 50,   //每天最大提取次数
        withdrawMaxAmount: 1000000000000,   // 每次最大提取数量
        randomSalt : 'hi,can-you-hear-me?',
        RankInitTs : 1555646400,
        rankRate : [
            47.887,
            23.943,
            11.972,
            5.986,
            2.993,
            1.496,
            1.197,
            0.958,
            0.766,
            0.613,
            0.490,
            0.392,
            0.314,
            0.251,
            0.201,
            0.161,
            0.129,
            0.103,
            0.082,
            0.066,
        ]
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_live',
        db_user: 'root',
        db_pwd: '',
        connectionLimit : 30,
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        privateKey : defaultPK,

        withdrawAddr : '414f012a6d5ecc301ec577714bb1431ed7e6f3ba0c',
        livePoolAddr : '41ba01bef5a503d3404e62b426b7e4e4595fe14530',
        rankwardAddr : '41d139a029d0de5172949fb01c565cb6eeeffbd4e9',

        masterFullNode: 'http://192.169.81.106:8090',
        masterSolidityNode: 'http://192.169.81.106:8091',
        masterEventNode: 'https://api.trongrid.io',

        slaveFullNode: 'http://192.169.80.102:8090',
        slaveSolidityNode: 'http://192.169.80.102:8091',
        slaveEventNode: 'https://api.trongrid.io',
    },
    EveryMatrix : {
        LoginName : 'EMLiveSlots2019',
        Password : 'EM!@#relawew$%^*()_2019'
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
} else {
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
