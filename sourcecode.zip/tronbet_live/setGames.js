const redisUtil = require('./src/utils/redisUtil')
const axios = require('axios')
const game = require('./src/service/games')

async function gameGames() {
    let games = await game.parseGames()
    await redisUtil.hset('tronlive:gamelist', 'games',JSON.stringify(games))
    console.log(games)
}

async function main() {
    await gameGames()
    process.exit(0)
}

main()