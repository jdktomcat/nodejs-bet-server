const TronWeb = require('tronweb');
const _ = require("lodash")._;
const BigNumber = require('bignumber.js');
const tronConfig = require('./src/configs/config').tronConfig
const sha3 = require('js-sha3')

let tronNodes = {
    master : new TronWeb(
        tronConfig.masterFullNode,
        tronConfig.masterSolidityNode,
        tronConfig.masterEventNode,
    ),
    slave : new TronWeb(
        tronConfig.slaveFullNode,
        tronConfig.slaveSolidityNode,
        tronConfig.slaveEventNode,
    )
}

function getTronWeb(node) {

    node = node || 'master'
    let result = tronNodes[node]

    if (_.isEmpty(result)) return null

    if (result.isConnected()) return result
    
    console.log('check tronweb connected failed, need to reload')
    return result
}

async function sendTRX(toAddr, amount, privateKey) {
    console.log('toAddr, amount----', toAddr, amount)
    let tronWeb = new TronWeb(
        tronConfig.masterFullNode,
        tronConfig.masterSolidityNode,
        tronConfig.masterEventNode,
        privateKey
    )
    let unsignedTransaction = await tronWeb.transactionBuilder.sendTrx(toAddr, Math.floor(amount * 1e6));
    let signdata = await tronWeb.trx.sign(unsignedTransaction, privateKey);
    let result = await tronWeb.trx.sendRawTransaction(signdata)
    return result
}

async function verifySignature(signature, address) {
    let msg = TronWeb.toHex('tronbet').substring(2);
    let tronWeb =  getTronWeb('master')
    try {
        let result = await tronWeb.trx.verifyMessage(msg, signature, address).catch((err) => {
            console.log(err)
            return false
        })
        return result
    } catch (error) {
        return false
    }
}

async function tronExec(contractAddr, fun_code, fee, callVal, params, privateKey) {
    let tronWeb = new TronWeb(
        tronConfig.masterFullNode,
        tronConfig.masterSolidityNode,
        tronConfig.masterEventNode,
        privateKey
    )
    console.log(contractAddr, fun_code, fee, callVal, params)
    let unsignedTransaction = await tronWeb.transactionBuilder.triggerSmartContract(contractAddr, fun_code, fee, callVal, params)
    // console.log(unsignedTransaction)
    let signdata = await tronWeb.trx.sign(unsignedTransaction.transaction, privateKey);
    let result = await tronWeb.trx.sendRawTransaction(signdata)
    return result
}

async function isTxSuccesssed(txId) {
    let tronWeb =  getTronWeb('master')
    let result = await tronWeb.trx.getTransaction(txId)

    console.log('result.ret[0].contractRet------>', result.ret)
    if (result != null && result.ret != null && result.ret[0].contractRet != null && result.ret[0].contractRet === "SUCCESS"){
        return true
    }
    return false
}

async function getAccBalance(addr, privateKey) {
    let tronWeb = new TronWeb(
        tronConfig.masterFullNode,
        tronConfig.masterSolidityNode,
        tronConfig.masterEventNode,
        privateKey
    )
    let res = await tronWeb.trx.getUnconfirmedBalance(addr)
    return res
}

module.exports = {
    sendTRX, 
    verifySignature, 
    tronExec, 
    isTxSuccesssed,
    getTronWeb,
    getAccBalance
}