const tronUtils = require('./robotUtils')

const redisUtil = require('./src/utils/redisUtil')

const common = require('./src/utils/common')

const db = require('./src/utils/dbUtil')

const tronweb = tronUtils.getTronWeb('master')

const axios = require('axios')

const evnets = require('events')

const appEvent = new evnets.EventEmitter()

const _ = require('lodash')._

let flag = true

let defaultPK = null;
try {
    defaultPK = require('/data/tronbet_project/config/privateKey').pk;
} catch (error) {
    console.log("using app pk");
    defaultPK = '54B730AB3B20B2A20E0BC5F00067B60395DBA549F9D319777BDD7C76B229BAFD';
}

let host = 'https://webliveapi.tronbet.io'

async function getAllAddrInfo() {
    let one = await redisUtil.hget('tronbet:live:addrinfo', 'info')
    if (!one) {
        return null
    }
    return JSON.parse(one)
}

async function testLogin(addr, sign) {
    let {data} = await axios({
        url : host  + "/user/login",
        data : {
            addr  :addr,
            sign : sign,
        },
        headers: { 'content-type': 'application/json'},
    })
    await updateSession(addr, data.data.sessionId)
    console.log(data)
}

async function testWithDraw(addr, sign, amount) {
    let {data} = await axios({
        url : host  + "/user/withdraw",
        method : 'post',
        data : {
            addr  : addr,
            sign : sign,
            amount : amount,
        },
        headers: { 'content-type': 'application/json'},
    })
    return data
}

async function tesPlatBalance(addr, sign) {
    let {data} = await axios({
        url : host  + "/user/balance",
        method : 'post',
        data : {
            addr  : addr,
            sign : sign,
        },
        headers: { 'content-type': 'application/json'},
    })
    return data
}


async function charge(privateKey, balance) {
    let result = await tronUtils.tronExec('414f012a6d5ecc301ec577714bb1431ed7e6f3ba0c', 'Deposit()', 5e6, Math.floor(balance / 1e6) * 1e6, [], privateKey).catch((err) =>{
        console.log('----------cccc-----------', err)
    })
    if (result.result == true) {
        console.log('Deposit balance success================>', balance)
        return true
    } else {
        console.log('Deposit balance failed================>', balance)
        return false
    }
    return false
}

async function withdraw(addr, balance, wOrderId) {
    let result = await tronUtils.tronExec('414f012a6d5ecc301ec577714bb1431ed7e6f3ba0c', 'Withdraw(address,uint256,uint256)', 5e6, 0, [{type : 'address', value : addr},
    {type : 'uint256', value : Math.floor(balance / 1e6) * 1e6},
    {type : 'uint256', value : '0x' + wOrderId}], defaultPK)
    return result
}

async function createAddrs(num) {
    let result = []
    for(let i =0; i<num; i++) {
        let info = await tronweb.createAccount()
        result.push(info)
    }
    return result
}

async function getSign(privateKey) {
    let timestamp = Math.floor(Date.now() / 1000)
    let utf8Str = "tronbet"
    hexStr = tronweb.fromUtf8(utf8Str)
    let addr = tronweb.defaultAddress.base58
    let sign = await tronweb.trx.sign(hexStr, privateKey)
    return sign
}

async function testGetAccountInfo() {
    let result = await tronUtils.getAccountName('TLA8xpn9uS7Wc5rdS8LLJJvQ3WbPVaitP3')
    console.log(result)
}

async function saveAddrInfo(addr, privateKey){
    let sql = 'insert into robot(addr, privateKey) values(?,?)'
    await db.exec(sql, [addr, privateKey])
}

async function getBalance(addr){
    let sql = 'select trx / 1000000 trx from live_user where addr = ?'
    let res = await db.exec(sql, [addr])
    if (_.isEmpty(res)) return 0
    return Number(res[0].trx)
}

async function updateSession(addr, SessionId) {
    let sql = "update robot set sessionId = ? where addr = ?"
    await db.exec(sql, [SessionId, addr])
}

async function getALLUsers(start, end) {
    let sql = "select * from robot limit ?, ?"
    return await db.exec(sql, [start, end])
}

async function registUser() {
    let addrs = await createAddrs(5000)
    for (let one of addrs) {
        await saveAddrInfo(one.address.base58, one.privateKey)
        // let sign  = await getSign(one.privateKey)
        // let addr = one.address.base58
        console.log('addr,sign----------------->', one.address.base58)
        // testLogin(addr, sign)
        // await common.sleep(50)
    }
}

async function addActiveUser(start, end) {
    let addrs = await getALLUsers(start, end)
    let lastAddr = 'TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi'
    let lastPrivateKey = 'D95A3CE00D91557116C692BA2251FBDCCFD5605D105076301028DF80C144DF1C'
    for (let one of addrs) {
        try {
            let lastBalance = await tronUtils.getAccBalance(lastAddr, lastPrivateKey)
            console.log('----lastAddr, lastBalance---->', lastBalance)
        if (lastBalance < 1e6) {
            lastAddr = 'TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi'
            lastPrivateKey = 'D95A3CE00D91557116C692BA2251FBDCCFD5605D105076301028DF80C144DF1C'
            continue
        }
        if(lastAddr == 'TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi') lastBalance = 30e6
        let flag = false
        console.log('actual lastAddr, lastBalance=========>', lastAddr, lastBalance / 1e6)
        let res = await tronUtils.sendTRX(one.addr, lastBalance / 1e6, lastPrivateKey).catch((error) => {
            console.log('-----try next------')
            flag = true
            return
        })
        if (flag) {
            await common.sleep(1000)
            continue
        }

        await common.sleep(1000)

        let balance = await tronUtils.getAccBalance(one.addr, one.privateKey)
        console.log('-----addr, balance------->', one.addr, balance)
        if (balance >= 1e6) {
            await charge(one.privateKey, balance)
            await common.sleep(10000)
            let sign  = await getSign(one.privateKey)
            let liveBalance = await tesPlatBalance(one.addr, sign)
            let num = (Math.floor(liveBalance.data.balance))
            if (num > 0) {
                await testWithDraw(one.addr, sign, num)
                await common.sleep(10000)
            }
            console.log('-----addr, liveBalance----', one.addr, liveBalance)
            
        }
        lastPrivateKey = one.privateKey
        lastAddr = one.addr
        } catch (error) {
            console.log('--------------error-------------')
            continue
        }
    }

    console.log('-------------------just end-----------------')
    let balance1 = await tronUtils.getAccBalance(lastAddr, lastPrivateKey)
    if(lastAddr != 'TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi') {
        let res = await tronUtils.sendTRX('TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi', Math.floor(balance1 / 1e6), lastPrivateKey).catch((error) => {
            console.log('transfererror')
        })
    }

    appEvent.emit('start_new_one', start, end)

}

async function start() {
    for (let i = 0; i< 2; i++) {
        setTimeout(async () => {
            appEvent.emit('start_new_one', 100 * i + 1, 600)
        }, i * 200)
    }
}

async function startCharge() {
    for (let i = 0; i< 20; i++) {
        setTimeout(async () => {
            appEvent.emit('rechatr', 100 * i + 1, 100)
        }, i * 200)
    }
}

async function rechagre(start, end) {
    let users = await getALLUsers(start, end)
    for (let one of users) {
        let sign  = await getSign(one.privateKey)

        let liveBalance = await getBalance(one.addr)
        let num = (Math.floor(liveBalance))
        if ( num > 1) {
            console.log('balance-------addr', one.addr, num)
            let res = await testWithDraw(one.addr, sign, num)
            console.log(res)
        }

        let balance =  await tronUtils.getAccBalance(one.addr, one.privateKey)
        if (balance > 2e6) {
            console.log('--------------send to TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi----->', balance)
            let res = await tronUtils.sendTRX('TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi', (balance / 1e6)  -1, one.privateKey).catch((error) => {
                console.log('-----try next------')
            })
        } 
    }
    appEvent.emit('rechatr',start, end)
}

async function AddAmount() {
    let addrs = await getALLUsers(3560, 2500)
    addrs = addrs.reverse()
    let ssLastAddr = addrs[0].addr
    let ssLastPK = addrs[0].privateKey
    let count = 0
    for (let one of addrs) {
        if (one.addr == ssLastAddr) {
            let lastbalance = await tronUtils.getAccBalance(ssLastAddr, ssLastPK)
            console.log('-------------------init-----------')
            if (lastbalance < 10e6) {
                let wpOrder = common.getRandomSeed(64)
                // if (flag) {
                //     flag = false
                //     let res1 = await withdraw(one.addr, 130000e6, wpOrder).catch((err) => {
                //         console.log('======withdraw1111 error======', err)
                //     })
                // }

                await common.sleep(5000)
            }
        }
        let lastbalance = await tronUtils.getAccBalance(ssLastAddr, ssLastPK)
        console.log('===================AmountAddFUNCtion, lastAddr ', ssLastAddr, ' ======================= lastBalance', 
        Math.floor(lastbalance / 1e6), '=======curAddr=== ', one.addr)
        if (lastbalance > 11e6) {
            let res = await tronUtils.sendTRX(one.addr, (lastbalance - 1e6) / 1e6, ssLastPK).catch((err) => {
                console.log('====error====', err)
            })
        } else {
            ssLastAddr = one.addr
            ssLastPK = one.privateKey
            count += 1
            continue
        }
        ssLastAddr = one.addr
        ssLastPK = one.privateKey
        await common.sleep(4000)
        let balance = await tronUtils.getAccBalance(one.addr, one.privateKey)
        if (balance > 11e6) {
            let res = await charge(one.privateKey, balance - 1e6)
            let wpOrder = common.getRandomSeed(64)
            if(res) {
                if (balance > 50000e6) balance = 50000e6
                let res1 = await withdraw(one.addr, balance - 1e6, wpOrder).catch((err) => {
                    console.log('======withdraw error======', err)
                })
                console.log('=============withdraw to addr, the balance==============', one.addr, Math.floor((balance - 1e6)/ 1e6), res1.result,balance)
            }
        } else {
            count += 1
            continue
        }
        await common.sleep(12000)
    }

    let lebalance = await tronUtils.getAccBalance(ssLastAddr, ssLastPK)
    if (lebalance > 11e6) {
        flag = false
        let res = await tronUtils.sendTRX(addrs[0].addr, (lebalance - 1e6) / 1e6, ssLastPK).catch((err) => {
            console.log('====error====', err)
        })
    } else {
        if (count >= 1950) flag = true
    }
    console.log('===========one round end=======')
    appEvent.emit('addAmount')
}

async function main() {

    // let sign  = await getSign('004130F5F7349D5219D685F05AAE5659CD6178F3FFB372D11B196B99E65FED4F')
    // let liveBalance = await tesPlatBalance('TNwTwNi5TKTXKxuZmaYmumjnk1BckLvvjh', sign)
    // console.log(liveBalance)
    // if (liveBalance.data.balance > 0) {
    //     let res = await testWithDraw('TNwTwNi5TKTXKxuZmaYmumjnk1BckLvvjh', sign, 3127)
    //     console.log(res)
    //     await common.sleep(30000)
    // }

    // let res1 = await tronUtils.sendTRX('TBQwZb5EMFGU9ey7Jr5MbnCEvsh8yjZLEi', 3108, '4E56D09F732FA6C60738A0D8DE0027D904B6244496B00E53840D88C6D4368011')
    // await testBet()
    // await addActiveUser('TQRMbC9WRmqatjeZShNBznsBUj1Ypo2Ndc', '5833b5f3db34674d4a3b45d1059b6427fea959651914e20e434b024533981635')
    // await registUser()
    // start()
    // startCharge()
    // start()
    // await AddAmount()
    appEvent.emit('addAmount')
}

appEvent.on('rechatr', async (start, end) => {
    await rechagre(start, end)
})

appEvent.on('addAmount', async (start, end) => {
    await AddAmount()
})

appEvent.on('start_new_one', (start, end) => {
    setTimeout(async () => {
        await addActiveUser(start, end)
    }, 300000);
    
})
main()
