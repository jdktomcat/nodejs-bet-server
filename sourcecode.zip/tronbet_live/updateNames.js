const redisUtils = require('./src/utils/redisUtil')
const db = require('./src/utils/dbUtil')
const redisUserKeyPrefix = 'live:user:'

async function getUsers() {
    let sql = "select addr from live_user where nickName is null"
    return await db.exec(sql, [])
}

async function updateUser(addr, nickName) {
    let sql = "update live_user set nickName = ? where addr = ?"
    return await db.exec(sql, [nickName, addr])
}

async function updateNames() {
    let users = await getUsers()
    for (let one of users) {
        let _name = await redisUtils.hget(redisUserKeyPrefix + one.addr, 'name')
        if (!_name || _name.length < 2) {
            continue
        }
        console.log(one.addr, _name)
        await updateUser(one.addr, _name)
    }
}

updateNames()