#!/bin/sh
npm run startrobot