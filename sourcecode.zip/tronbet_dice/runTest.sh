#!/bin/sh
npm run test