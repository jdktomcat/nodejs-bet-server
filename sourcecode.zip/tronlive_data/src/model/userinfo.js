const db = require('../utils/dbUtil')
const _ = require('lodash')._
const poker = require('../utils/poker')

const MaxFreeSpins = 20
const MinBet2GetFreeSpin = 10000 

async function getLastDividends(startTs) {
    let sql = "select total_trx * 0.15 trx, send_ts ts, 'LIVE' types from live_div_info where send_ts >= ?"
    let res = await db.exec(sql, [startTs])
    return res
}

async function getLiveBetData(startTs, endTs) {
    let sql = "select addr, sum(amount) amount, sum(win) win from (select addr, case action when 'bet' then Amount else 0 end as amount, case action when 'result' then Amount else 0 end as win from tron_live.live_action_log where ts >= ? and ts < ? and txStatus = 1) a group by addr"
    let res = await db.exec(sql, [startTs, endTs])
    return res
}

async function getLastTs(){
    let sql = "select max(ts) ts from tron_live.live_bet_info"
    let res = await db.exec(sql, [])
    if(_.isEmpty(res)) return 0
    return res[0].ts || 0
}

async function updateBetInfo(round, addr, amount, win, ts, conn){
    let sql = "insert into live_bet_info(round, addr, amount, win, ts) values(?,?,?,?,?) ON DUPLICATE KEY UPDATE amount = amount + ?, win = win + ?, ts = ?"
    return await db.execTrans(sql, [round, addr, amount * 1e6, win * 1e6, ts, amount * 1e6, win * 1e6, ts], conn)
}

async function getFreespinNum(addr) {
    let sql = 'select fsNum from live_freespin_user where addr = ?'
    let res = await db.exec(sql, [addr])
    if(_.isEmpty(res)) return 0
    return res[0].fsNum
}

async function addFreeSpinUser(addr,nickName, userId, num) {
    let num = await getFreespinNum(addr)
    if (num >= MaxFreeSpins) return
    let sql = "insert into live_freespin_user(addr, nickName, emUserId, fsNum) values(?,?,?,?) on DUPLICATE KEY UPDATE fsNum = fsNum + ?"
    let res = await db.exec(sql, [addr, nickName, userId, num, num])
    return res
}

async function addFreeSpinLog(addr, orderId, endTs, ts) {
    let sql = 'insert into live_freespin_log(addr, orderId, endTs, ts) values(?,?,?,?)'
    let res = await db.exec(sql, [addr, orderId, endTs, ts])
    return res
}

async function getNewUsers() {
    let sql = "select addr from live_user where addr not in (select addr from live_tmp_new_user)"
    let res = await db.exec(sql, [])
    return res
}

async function addNewTmpUsers() {
    let users = await getNewUsers()
    if (_.isEmpty(users)) return
    let sql = "insert into live_tmp_new_user(addr, ts) values(?,?)"
    let now = new Date().getTime()
    for (let one of users) {
        await db.exec(sql, [one.addr, now])
    }
}

async function getNeedToSendFreeSpinUsers() {
    let minTime = Date.getTime() - 7 * 86400 * 1000
    let sql = "select addr, sum(amount) amount from live_bet_info where addr in (select addr from live_tmp_new_user where ts > ?) and sum(amount) > ? and addr not in (select addr from live_freespin_user)"
    let res = await db.exec(sql, [minTime, MinBet2GetFreeSpin])
    return res
}

module.exports = {
    getLastDividends,
    getLastTs,
    updateBetInfo,
    getLiveBetData,
    addNewTmpUsers,
    addFreeSpinLog,
    addFreeSpinUser,
    getNeedToSendFreeSpinUsers,
}