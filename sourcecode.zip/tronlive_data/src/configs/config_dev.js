const fs = require('fs');
const path = require('path');
let config = {
    env: 'dev',
    debug: false,
    app: {
        http_port : 8370,
        websocket_port: 9012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志,
        withdrawMaxTimes : 100,   //每天最大提取次数
        withdrawMaxAmount: 1000000000000,   // 每次最大提取数量
        randomSalt : 'hi,can-you-hear-me?',
    },
    mysqlConfig: {
        db_host: '192.169.80.102',
        db_port: '3306',
        db_name: 'tron_live',
        db_user: 'root',
        db_pwd: '',
        connectionLimit : 5,
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        privateKey : '',
        payPKHex : '414915E5501D1F01DDB5EF8983B6877874A83FCC57',

        withdrawAddr : '41f9529ea18844aff7faca04443beffc74832b8232',
        livePoolAddr : '416dd58ffa37007d861f5d5455b21c273f15fa9f69',


        // masterFullNode : 'http://10.4.24.126:8090',
        // masterSolidityNode : 'http://10.4.24.126:8091',
        // masterEventNode : 'https://api.trongrid.io',

        masterFullNode : 'https://api.shasta.trongrid.io',
        masterSolidityNode : 'https://api.shasta.trongrid.io',
        masterEventNode : 'https://api.trongrid.io',

        slaveFullNode : 'https://api.trongrid.io',
        slaveSolidityNode : 'https://api.trongrid.io',
        slaveEventNode : 'https://api.trongrid.io',
    },
    rewards : [0, 0, 2, 20, 40, 50,200, 400, 600, 10000000, 100000000],
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
} else {
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
