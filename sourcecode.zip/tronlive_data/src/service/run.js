const usermodel = require('../model/userinfo')
const _ = require('lodash')._
const redisUtil = require('../utils/redisUtil')
const db = require('../utils/dbUtil')
const freespin = require('./freespins')


let updateBetInfo = setInterval(async () => {
    let startTs = await usermodel.getLastTs()
    let now = Math.floor(new Date().getTime())
    console.log('----------startTs----endts-----start--------', startTs, now)
    let res = await usermodel.getLiveBetData(startTs, now)
    console.log('----------startTs----endts-------end------', startTs, now)
    let round = Math.floor((now - 1556251200000) / 604800000) 
    let conn = null
    try {
        conn = await db.getConnection()
        if (!conn) {
            console.error('damn it, connection lost, please check it')
            return
        }
        for (let one of res) {
            await usermodel.updateBetInfo(round, one.addr, one.amount, one.win, now, conn)
        }
        conn.commit()
    } catch (error) {
        console.log(error)
        if (conn) conn.release()
    } finally {
        if (conn) conn.release()
    }
}, 120000)


let addFreeSpinTimer = setInterval(async () => {
    let users = await usermodel.getNeedToSendFreeSpinUsers()  //获取满足条件的用户， 新用户注册7天之后在下注， 是不会获得奖励的， 获得过一次奖励之后， 也不能再次获得
    // TODO
    // 在EM侧创建用户
    for(let one of users) {
        let createRes = await freespin.createFreespinUser(one.addr)
        let sendRes = await freespin.sendFreepins(addr, createRes.userId, 1002)
    }
    // 想EM发送freespin
    // 添加发送日志
    // end
}, 180000)

let addTmpUserTimer = setInterval(async () => {
    await usermodel.addNewTmpUsers() // 识别新用户
}, 180000)