"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const thinkjs_1 = require("thinkjs");
var redis = require("redis");
var client = require("redis").createClient({
    host: 'localhost',
    port: thinkjs_1.think.config('redisPort'),
    password: thinkjs_1.think.config('redisPwd'),
    db: 1
});
var client1 = require("redis").createClient({
    host: 'localhost',
    port: thinkjs_1.think.config('redisPort'),
    password: thinkjs_1.think.config('redisPwd'),
    db: 1
});
let dealWithMsg = null;
thinkjs_1.think.messenger.on('consumeEvent', (data) => {
});
client.on("ready", function () {
    client.subscribe("game_message");
    client.subscribe("chat1");
    console.log("订阅成功。。。");
});
client.on("error", function (error) {
    console.log("Redis Error " + error);
});
client.on("subscribe", function (channel, count) {
    console.log("client subscribed to " + channel + "," + count + "total subscriptions");
});
client.on("message", (channel, message) => __awaiter(this, void 0, void 0, function* () {
    console.log("我接收到信息了" + message);
    yield dealWithMsg(message);
}));
client.on("unsubscribe", function (channel, count) {
    console.log("client unsubscribed from" + channel + ", " + count + " total subscriptions");
});
thinkjs_1.think.app.on("appReady", () => __awaiter(this, void 0, void 0, function* () {
    let now = new Date().getTime();
    if (now > 1546401600000) {
        return;
    }
    let betModel = thinkjs_1.think.model('mysql/chris_bet_order');
    console.log('appredadd------------------');
    dealWithMsg = (message) => __awaiter(this, void 0, void 0, function* () {
        console.log(thinkjs_1.think.model);
        try {
            let info = JSON.parse(message);
            let now = new Date().getTime();
            yield betModel.startTrans();
            let order_id = info.order_id;
            if (info.game_type == 'moon') {
                order_id = 10000000 + info.order_id;
            }
            else if (info.game_type == 'dice') {
                console.log('----do nothing---');
            }
            yield betModel.add({
                addr: info.addr,
                bet_id: order_id,
                ts: now,
                num: 1
            });
            let sql = "insert into chris_box(addr, num) values ('%s',1) ON DUPLICATE KEY update num = num + 1;";
            let sqlObj = yield betModel.parseSql(sql, info.addr);
            yield betModel.query(sqlObj);
            yield betModel.commit();
        }
        catch (error) {
            yield betModel.rollback();
            console.log('000000');
        }
    });
}));
//# sourceMappingURL=worker.js.map