"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const thinkjs_1 = require("thinkjs");
var TronWeb = require('tronweb');
var xhr = require('axios');
var _ = require('underscore')._;
var util = require('util');
var BigNumber = require('bignumber.js');
const HttpProvider = TronWeb.providers.HttpProvider;
var fullNode = new HttpProvider(thinkjs_1.think.config('fullNode'));
var solidityNode = new HttpProvider(thinkjs_1.think.config('solidityNode'));
var eventServer = thinkjs_1.think.config('eventServer');
var privateKey = thinkjs_1.think.config('privateKey');
const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, privateKey);
class default_1 extends thinkjs_1.think.Service {
    tronQuery(contractAddr, fun_code, params, privateKey, _callback) {
        if (_.isEmpty(contractAddr) || _.isEmpty(fun_code))
            return;
        params = params || [];
        return new Promise((resolve, reject) => {
            let errMsg = null;
            if (tronWeb == null)
                return null;
            if (privateKey != null)
                tronWeb.setPrivateKey(privateKey);
            tronWeb.transactionBuilder.triggerSmartContract(contractAddr, fun_code, 10, 0, params, (err, result) => {
                if (err) {
                    errMsg = "tronQuery -> result -> error" + err;
                    if (_callback)
                        _callback(errMsg, null);
                    reject(errMsg);
                }
                ;
                if (result && result.result.result === true) {
                    let hexStr = result.constant_result[0];
                    if (_.isEmpty(hexStr)) {
                        errMsg = "tronQuery -> result -> empty";
                        if (_callback)
                            _callback(errMsg, null);
                        reject(errMsg);
                    }
                    if (_callback)
                        _callback(null, hexStr);
                    resolve(hexStr);
                }
                else {
                    errMsg = "tronQuery -> result -> fail";
                    if (_callback)
                        _callback(errMsg, null);
                    reject(errMsg);
                }
            });
        });
    }
    getMaxOrder() {
        return __awaiter(this, void 0, void 0, function* () {
            let data = yield this.tronQuery(thinkjs_1.think.config('tronChristmasActAddress'), "getMaxOrderId()", [], null, null);
            console.log(data);
            let orderId = new BigNumber(data, 16).toNumber();
            console.log(orderId);
            return orderId;
        });
    }
    getOrders(from, to) {
        return __awaiter(this, void 0, void 0, function* () {
            let startTs = Date.now();
            let data = yield this.tronQuery(thinkjs_1.think.config('tronChristmasActAddress'), "getOrders(uint256,uint256)", [{ type: "uint256", value: from }, { type: "uint256", value: to }], null, null);
            console.log(data);
            let orderIdArray = yield this.getUint256Arr(data, 256);
            console.log(orderIdArray);
            let _playerArrayStartIndex = orderIdArray[1];
            let playerArray = yield this.getAddressArr(data, _playerArrayStartIndex);
            console.log(playerArray);
            let _txtArrayStartIndex = playerArray[1];
            let txtArray = yield this.getUint256Arr(data, _txtArrayStartIndex);
            console.log(txtArray);
            let _giftIdArrayStartIndex = txtArray[1];
            let giftIdArray = yield this.getUint256Arr(data, _giftIdArrayStartIndex);
            console.log(giftIdArray);
            let result = [];
            for (let i = 0; i < orderIdArray[0].length; i++) {
                let tmp = {
                    order_id: orderIdArray[0][i],
                    addr: playerArray[0][i],
                    amount: txtArray[0][i] / 1e6,
                    num: giftIdArray[0][i] == 2 ? 100 : 10
                };
                result.push(tmp);
            }
            console.log(result);
            return result;
        });
    }
    hexStringToBigNumber(_hexStr) {
        return __awaiter(this, void 0, void 0, function* () {
            return new BigNumber(_hexStr, 16).toNumber();
        });
    }
    hexStringToTronAddress(_hexStr) {
        return __awaiter(this, void 0, void 0, function* () {
            return TronWeb.address.fromHex('41' + _hexStr);
        });
    }
    getAddressArr(data, _startIndex) {
        return __awaiter(this, void 0, void 0, function* () {
            let addressArr = new Array();
            let startIndex = _startIndex;
            let arrLen = yield this.hexStringToBigNumber(data.substr(startIndex, 64));
            console.log('----------arrLen---------', arrLen);
            startIndex = startIndex + 64;
            for (let idx = 0; idx < arrLen; idx++) {
                addressArr.push(yield this.hexStringToTronAddress(data.substr(startIndex + idx * 64 + 24, 40)));
            }
            let _endIndex = _startIndex + (arrLen + 1) * 64;
            return [addressArr, _endIndex];
        });
    }
    getUint256Arr(data, _startIndex) {
        return __awaiter(this, void 0, void 0, function* () {
            let uint256Arr = new Array();
            let startIndex = _startIndex;
            let arrLen = yield this.hexStringToBigNumber(data.substr(startIndex, 64));
            startIndex = startIndex + 64;
            for (let idx = 0; idx < arrLen; idx++) {
                uint256Arr.push(yield this.hexStringToBigNumber(data.substr(startIndex + idx * 64, 64)));
            }
            let _endIndex = _startIndex + (arrLen + 1) * 64;
            return [uint256Arr, _endIndex];
        });
    }
    openBox(num) {
        return __awaiter(this, void 0, void 0, function* () {
            if (num > 1) {
                return yield this.openMultiBox(num);
            }
            else {
                return [yield this.open1Box()];
            }
        });
    }
    open1Box() {
        return __awaiter(this, void 0, void 0, function* () {
            let luckyNum = yield this.getRandomInt(1, 38628);
            let sum = 0;
            let rate = thinkjs_1.think.config('goodsRate');
            for (let i = 0; i < rate.length; i++) {
                sum = rate[i];
                if (sum >= luckyNum)
                    return i + 1;
            }
            return 1;
        });
    }
    openMultiBox(num) {
        return __awaiter(this, void 0, void 0, function* () {
            let result = [];
            for (let i = 0; i < num; i++) {
                result.push(yield this.open1Box());
            }
            return result;
        });
    }
    getRandomInt(min, max) {
        return __awaiter(this, void 0, void 0, function* () {
            min = Math.ceil(min);
            max = Math.floor(max);
            return Math.floor(Math.random() * (max - min + 1)) + min;
        });
    }
    pay2User(address, amount) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(address, amount);
            try {
                let newAddress = yield tronWeb.address.toHex(address);
                console.log(newAddress);
                let { data } = yield xhr({
                    url: thinkjs_1.think.config('nodepay') + '/wallet/easytransferbyprivate',
                    method: 'post',
                    data: {
                        privateKey: thinkjs_1.think.config('payPrivateKey'),
                        toAddress: newAddress,
                        amount: Math.floor(amount * 1000000),
                    },
                    headers: {
                        'Content-type': 'application/json', 'Accept': 'text/plain'
                    }
                });
                let txID = data.transaction.txID;
                console.log(util.format('k:%s,%s TRX,交易hash:%s---已经入库', address, amount.toString(), txID));
                return txID;
            }
            catch (error) {
                console.log(error);
                return null;
            }
        });
    }
    getMainAccBalance() {
        return __awaiter(this, void 0, void 0, function* () {
            let { data } = yield xhr({
                url: thinkjs_1.think.config('nodepay') + "/wallet/getaccount",
                method: 'post',
                data: {
                    address: thinkjs_1.think.config('publicKeyHex'),
                },
                headers: {
                    'Content-type': 'application/json', 'Accept': 'text/plain'
                }
            });
            console.log(thinkjs_1.think.config('publicKeyHex'));
            let balance = data.balance / 1e6;
            return balance;
        });
    }
}
exports.default = default_1;
//# sourceMappingURL=trade.js.map