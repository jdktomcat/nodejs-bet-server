module.exports = [];
//# sourceMappingURL=router.js.map