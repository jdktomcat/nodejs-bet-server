"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const thinkjs_1 = require("thinkjs");
class default_1 extends thinkjs_1.think.Model {
}
exports.default = default_1;
//# sourceMappingURL=index.js.map