"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const thinkjs_1 = require("thinkjs");
class default_1 extends thinkjs_1.think.Model {
    get relation() {
        return {
            chris_log_detail: {
                type: thinkjs_1.think.Model.HAS_MANY,
                key: 'log_id',
                fKey: 'log_id',
            },
        };
    }
    getLogs(addr) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.where({ addr: addr }).order('log_id desc').limit(30).select();
        });
    }
}
exports.default = default_1;
//# sourceMappingURL=chris_oprate_logs.js.map