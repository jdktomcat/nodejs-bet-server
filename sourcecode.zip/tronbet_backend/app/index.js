"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ThinkJS = require("../node_modules/thinkjs");
require("./extend/controller");
require("./extend/logic");
require("./extend/context");
require("./extend/think");
require("./extend/service");
require("./extend/application");
require("./extend/request");
require("./extend/response");
require("think-view");
require("think-model");
require("think-cache");
require("think-session");
exports.think = ThinkJS.think;
//# sourceMappingURL=index.js.map