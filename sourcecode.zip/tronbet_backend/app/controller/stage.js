"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const base_js_1 = require("./base.js");
var redis = require('redis');
var TronWeb = require('tronweb');
var xhr = require('axios');
class default_1 extends base_js_1.default {
    overviewAction() {
        return __awaiter(this, void 0, void 0, function* () {
            let method = this.method.toLowerCase();
            if (method === "options") {
                console.error(method);
                return this.success('ok');
            }
            let role = this.ctx.param('role');
            if (Number(role) != 0) {
                return this.success([]);
            }
            let game = this.post('game');
            console.log(game, '------------------------');
            if (game != 'All' && game != 'Dice' && game != 'Moon' && game != 'Ring' && game != 'Duel') {
                return this.success([]);
            }
            let tmodel = this.model("dice_events_roll_0", "mysql2");
            let initTs = 1556164800;
            let now = Math.floor(new Date().getTime() / 1000);
            let startTs = Math.floor((now - initTs) / 86400) * 86400 + 1556164800;
            if (game == 'dice') {
                let minSql = "select * from tron_bet_admin.dice_player_order where ts >= %s limit 1";
                let minSqlParse = yield tmodel.parseSql(minSql, startTs * 1000);
                let result = yield tmodel.query(minSqlParse);
            }
        });
    }
}
exports.default = default_1;
//# sourceMappingURL=stage.js.map