"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const base_js_1 = require("./base.js");
var redis = require('redis');
class default_1 extends base_js_1.default {
    energyAction() {
        return __awaiter(this, void 0, void 0, function* () {
            let role = this.ctx.param('role');
            if (Number(role) != 0) {
                return this.success([]);
            }
            let tmodel = this.model("dice_events_roll_0", "mysql2");
            let nowTime = new Date().getTime();
            let lastTime = nowTime - 86400000;
            let totalEnergySql = "select sum(energy) energy from dice_txs where block_num >= (select min(block_num) from dice_block where block_ts >= " + lastTime + ");";
            let lessThan8wEnergySql = "select sum(energy) energy from dice_txs where energy <= 80000 and block_num >= (select min(block_num) from dice_block where block_ts >= " + lastTime + ");";
            let maxEnergySql = "select max(energy) energy from dice_txs where block_num >= (select min(block_num) from dice_block where block_ts >= " + lastTime + ");";
            let rankEnergySql = "select block_num, tx_id, energy from dice_txs where energy > 100000 and block_num >= (select min(block_num) from dice_block where  block_ts >= " + lastTime + ") order by energy desc limit 20;";
            let totalEnergy = yield tmodel.query(totalEnergySql);
            let lessThan8wEnergy = yield tmodel.query(lessThan8wEnergySql);
            let maxEnergy = yield tmodel.query(maxEnergySql);
            let rankEnergy = yield tmodel.query(rankEnergySql);
            this.success({
                totalEnergy: totalEnergy[0].energy,
                lessThan8wEnergy: lessThan8wEnergy[0].energy,
                maxEnergy: maxEnergy[0].energy,
                rankEnergy: rankEnergy,
            });
        });
    }
    chartsAction() {
        return __awaiter(this, void 0, void 0, function* () {
            let role = this.ctx.param('role');
            if (Number(role) != 0) {
                return this.success([]);
            }
            let tmodel = this.model("histline");
            let nowTime = Math.floor(new Date().getTime() / 1000);
            let todatStime = (nowTime - nowTime % 86400 - 8 * 3600);
            if (nowTime % 86400 >= 16 * 3600) {
                todatStime = todatStime + 86400;
            }
            let stime = (todatStime - 7 * 86400);
            let sql = "select date,amount,profit,cnt,users,newuser from histline where date >= " + stime + " order by date;";
            let result = yield tmodel.query(sql);
            this.success({
                result: result
            });
        });
    }
}
exports.default = default_1;
//# sourceMappingURL=chart.js.map