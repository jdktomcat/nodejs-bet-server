#!/bin/bash
node production.js