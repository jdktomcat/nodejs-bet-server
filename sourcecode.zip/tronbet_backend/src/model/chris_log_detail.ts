import { think } from 'thinkjs';

export default class extends think.Model {
}
