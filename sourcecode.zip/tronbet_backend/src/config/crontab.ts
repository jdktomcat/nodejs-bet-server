module.exports = [{
    interval: 5000,
    immediate: true,
    handle: '/update/cronrank'
  },
]

// module.exports = [
  
// ]