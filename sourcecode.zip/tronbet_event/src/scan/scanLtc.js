const axois = require('axios')
const _ = require('lodash')._
const utils = require('./utils')
const fs = require('fs')
const log4js = require('../configs/log4js.config')
const logger = log4js.getLogger('ltc');

const startBlockNum = 1644958

const scanHost = 'https://chainz.cryptoid.info'  
const donateAddr = 'ltc1qw7x29r30kazustquxtkpct9dzw43m78spu08cn'   //TODO change to real one
const token = '5d8d5a5e1f0c47b5a3af8688c880ee2e'

async function RecordBlockNum(block_num) {
    try {
        fs.writeFile('liteCoinBlockNum', block_num, (err, data) =>{
        })
    } catch(e) {
        logger.info('Failed....', e)
    }
    return true
}

async function getMaxBlockNum() {
    try {
        var data = fs.readFileSync('liteCoinBlockNum');
        let blockNum = Number(data.toString())
        if (blockNum <= startBlockNum) return startBlockNum
        return blockNum
    } catch(e) {
        return startBlockNum
    }
}

async function getAllBnBTransactions(blockNum) {
    try {
        let blockHash = await getBlockHashByHeight(blockNum)
        if (!blockHash) return false
        let now = new Date().getTime()
        let randomEnd = utils.randomString(2)
        let blockInfoUrl = scanHost + '/explorer/block.raw.dws?coin=ltc&hash=' + blockHash + '.' + randomEnd
        logger.info(blockInfoUrl)
        let {data} = await axois.get(blockInfoUrl)
        if (_.isEmpty(data)) return false
        if(data.confirmations < 6) return false

        let allInfoUrl = scanHost + '/explorer/block.txs.dws?coin=ltc&h=' + blockHash + '.' + randomEnd
        let allTxs = await axois.get(allInfoUrl)
        let allTxInfo = allTxs.data
        // logger.info(allTxInfo)
        for (let one of allTxInfo) {
            let donors = await getDonorAddr(one.outputs)
            if (!donors) continue
            let donater = await getMostAmountAddr(one.inputs)
            if(!donater) return
            let tmp = {
                addr : donater,
                amount : donors.amount,
                ts : now,
                txId : one.hash,
                blockNum : blockNum,
                coinType : 'ltc',
            }
            let result = await utils.dealDonates(tmp)
            if (!result) return false
        }
    } catch (error) {
        logger.info(error)
        return false
    }
    return true
}

async function getDonorAddr(outputs) {
    let result = null
    for(let one of outputs) {
        if (one.a == donateAddr) {
            return {addr : one.a, amount : one.v}
        }
    }
    return null
}

async function getMostAmountAddr(inputs) {
    let amount = 0
    let addr = ''
    for (let one of inputs) {
        if (one.v > amount) {
            amount = one.v
            addr = one.a
        }
    }
    if (amount >0) return addr
    return null
}

async function getBlockHashByHeight(blockNum) {
    let url = scanHost + "/ltc/api.dws?q=getblockhash&height=" + blockNum
    try {
        let {data} = await axois.get(url)
        return data
    } catch (error) {
        return null
    }
    return null
}
async function scanNext(blockNum) {
    let result = await getAllBnBTransactions(blockNum)
    return result
}

async function main() {
    let blockNum = await getMaxBlockNum() + 1
    while (true) {
        let stime = new Date().getTime()
        let result = await scanNext(blockNum)
        if (result) {
            await RecordBlockNum(blockNum)
            logger.info('-----finish litecoin block num ', blockNum, ' in ', new Date().getTime() - stime, 'ms')
            blockNum += 1
            await utils.sleep(10000)
        } else {
            logger.info('-----------restart litecoin blockNum : ', blockNum)
            await utils.sleep(180000)
        }
    }
}

main()