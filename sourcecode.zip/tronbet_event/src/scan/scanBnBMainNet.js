const axois = require('axios')
const _ = require('lodash')._
const utils = require('./utils')
const fs = require('fs')
const log4js = require('../configs/log4js.config')
const logger = log4js.getLogger('bnb')
const moment = require('moment')

let startBlockNum = 1559530204029   // 其实是时间

const donateAddr = 'bnb1pdvvmfypc6dl0kpqx9fjp7zycgj84zmrgsuru7'   //TODO change to real one
const scanHost = 'https://dex.binance.org/api/v1/transactions?address=' + donateAddr + '&txAsset=BNB&txType=TRANSFER&side=RECEIVE'

async function RecordBlockNum(block_num) {
    try {
        fs.writeFile('BNBMAINNETTIME', block_num, (err, data) =>{
        })
    } catch(e) {
        logger.info('Failed....', e)
    }
    return true
}

async function getMaxBlockNum() {
    try {
        var data = fs.readFileSync('BNBMAINNETTIME');
        let blockNum = Number(data.toString())
        if (blockNum <= startBlockNum) return startBlockNum
        return blockNum
    } catch(e) {
        return startBlockNum
    }
}

async function getAllBnBTransactions(stime, etime) {
    let url = scanHost + '&startTime=' + stime + '&endTime=' + etime
    try {
        let {data} = await axois.get(url)
        logger.info(url)
        logger.info(data)
        if(_.isEmpty(data.tx)) return true
        for(let one of data.tx) {
            if (one.code != 0) continue
            let transUser = {
                addr : one.fromAddr,
                amount : Number(one.value),
                ts : new Date(one.timeStamp).getTime(),
                txId : one.txHash,
                blockNum : one.blockHeight,
                coinType : 'bnb',
            }
            logger.info(transUser)
            let result = await utils.dealDonates(transUser)
            if (!result) return false
        }
        return true   
    } catch (error) {
        logger.info(error)
        return false
    }

}

async function scanNext(stime, etime) {
    let result = await getAllBnBTransactions(stime, etime)
    return result
}

async function main() {
    let blockNum = await getMaxBlockNum()
    while (true) {
        let startScantime = new Date().getTime()
        let lastScanTime = startScantime - 8 * 60 * 1000
        if (lastScanTime > blockNum) {
            lastScanTime = blockNum
        }
        let result = await scanNext(lastScanTime, startScantime)
        if (result) {
            await RecordBlockNum(startScantime)
            blockNum = startScantime
            logger.info('-----finish bnb blockNum ', startScantime, ' in ', new Date().getTime() - startScantime, 'ms')
            await utils.sleep(30000)
        } else {
            logger.info('-----------restart bnb blockNum : ', blockNum)
            await utils.sleep(10000)
        }
    }
}


//注意， 这里是按照时间取的bnb的tx 并不是按照区块高度扫描的
main()
