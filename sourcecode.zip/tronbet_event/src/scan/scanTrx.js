var xhr = require('axios')
var fs = require("fs")
const _ = require('loadsh')._
const TronWeb = require('tronweb')
const moment = require('moment')
const sha3 = require('js-sha3')
const BigNumber = require('bignumber.js')
const utils = require('./utils')
const log4js = require('../configs/log4js.config')
const logger = log4js.getLogger('trx');

const donateAddr = 'TAaFxF2jGpyDibyfCB8FKoLMJdqM4rk6qD'
const hosts = "http://192.169.80.102:8091"

async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

async function RecordBlockNum(block_num) {
    try {
        fs.writeFile('charityTrxBlockNum', block_num, (err, data) =>{
        })
    } catch(e) {
        logger.info('Failed....')
    }
    return true
}

async function getMaxBlockNum() {
    try {
        var data = fs.readFileSync('charityTrxBlockNum');
        let blockNum = Number(data.toString())
        return blockNum
    } catch(e) {
        return 	9791630
    }
}

async function getnowblock() {
    let {data} =  await xhr({
        url : hosts + '/walletsolidity/getnowblock',
        method : 'post',
        data : {}
    })
    return data
}

async function getBlockData(blockNum) {
    let {data} =  await xhr({
        url : hosts + '/walletsolidity/getblockbynum',
        method : 'post',
        data : {
            num: blockNum
        }
    })
    return data
}

async function alysisBlockData(blockData, blockNumber) {
    let ts = blockData.block_header.raw_data.timestamp;
    let transactions = blockData.transactions;
    let result = true
    if (transactions && !_.isEmpty(transactions) && _.isArray(transactions) && transactions.length > 0) {
        let txCount = transactions ? transactions.length : 0;
        logger.info("-----------------------------------------------------------------------------------------------------------------");
        logger.info("TRX区块:" + blockNumber + "; 出块时间:" + moment(ts).format('YYYY-MM-DD HH:mm:ss') + "; transactionnum:" + txCount);
        await Promise.all(transactions.map(async (txInfo) => {
            if (txInfo.ret[0].contractRet != 'SUCCESS') {
                return
            }
            let tmp = await alysisTxs(txInfo)
            if (!tmp) {
                logger.info('-------------------blockNumber----------failed---', blockNumber)
                result = false
            }
        }))
    }
    return result
}

async function gettransactioninfobyid(txID){
    let {data} = await xhr({
        url : hosts + '/walletsolidity/gettransactioninfobyid',
        method : 'post',
        data : {
            value : txID
        }
    })
    return data
}

async function alysisTxs(tx){
    let txID = tx.txID
    let raw_data = tx.raw_data
    let contract = raw_data.contract
    let fee_limit = raw_data.fee_limit
    let timestamp = raw_data.timestamp
    let now = new Date().getTime()
    if (timestamp < 1560129007274){
        timestamp = now
    }
    let sign = tx.signature[0]
    let res = null;
    
    for (let _contract of contract) {
        let type = _contract.type;
        // logger.info(type)
        if (type != "TransferContract") continue

        let value = _contract.parameter.value
        if (value) {
            let toAddr = hexStringToTronAddress(value.to_address)
            if (toAddr === donateAddr) {
                let tmp = {
                    addr : hexStringToTronAddress(value.owner_address),
                    amount : value.amount / 1e6,
                    ts : timestamp || now,
                    txId : txID,
                    blockNum : 1,
                    toAddr : hexStringToTronAddress(value.to_address),
                    coinType : 'trx',
                }
                let result = await utils.dealDonates(tmp)
                if (!result) return false
            }
        }
        // logger.info(_contract)
    }
    return true
}


function hexStringToTronAddress1(_hexStr) {
    return TronWeb.address.fromHex(_hexStr);
}

async function scanNext(blockNum) {
    try {
        let blockData = await getBlockData(blockNum)
        // logger.info(JSON.stringify(blockData))
        // process.exit(0)
        if (_.isEmpty(blockData)) {
            return false
        }
        let result = await alysisBlockData(blockData, blockNum)
        return result
    } catch(e) {
        logger.info(e)
        return false
    }
}

function hexStringToBigNumber(_hexStr) {
    return new BigNumber(_hexStr, 16);
}

EMPTY_ADDRESS = "0000000000000000000000000000000000000000";
function hexStringToTronAddress(_hexStr) {
    if (_hexStr === EMPTY_ADDRESS) {
        return "";
    }
    return TronWeb.address.fromHex(_hexStr);
}

async function main() {
    let blockNum = await getMaxBlockNum() + 1
    while (true) {
        let stime = new Date().getTime()
        let result = await scanNext(blockNum)
        if (result) {
            await RecordBlockNum(blockNum)
            logger.info('-----finish trx block num ', blockNum, ' in ', new Date().getTime() - stime, 'ms')
            blockNum += 1
        } else {
            logger.info('-----------restart trx blockNum : ', blockNum)
            await sleep(3100)
        }
        
    }
    
}

main()