const usermodel = require('../model/userinfo')
const log4js = require('../configs/log4js.config')
const loggerDefault = log4js.getLogger('print')
const _ = require('lodash')._
const crypto = require("crypto")
const {softswiss, rewards}  = require('../configs/config')
const evnets = require('events')
const common = require('../utils/common')
const actionEvent = new evnets.EventEmitter()
const TronWeb = require('tronweb')
const userinfo = require('../model/userinfo')
const {sha256} = require('js-sha256')
const db = require('../utils/dbUtil')
const poker = require('../utils/poker')
const redisUtil = require('../utils/redisUtil')
const tronUtils = require('../utils/tronUtil')


async function sendMsgToClient(ctx, errno, errmsg, data) {
    let result = {
        errno : errno,
        errmsg : errmsg,
        data : data
    }
    ctx.body = result
}

async function getCharityCodeByAddr(ctx) {
    let params = ctx.request.body
    if (_.isEmpty(params)) params = ctx.request.query 
    let addr = params.addr
    if (!addr || addr.length < 10) return await  sendMsgToClient(ctx, 1001,'address error')
    let res = await userinfo.getCharityCodeByAddr(addr)
    return sendMsgToClient(ctx, 0, '', res)
}

async function getLastCharityCodes(ctx) {
    let res = await redisUtil.hget('charity:lastest:rank', 'rank')
    if (res) {
        try {
            return sendMsgToClient(ctx, 0, '', JSON.parse(res))
        } catch (error) {
            console.log('----parse error-----')
            return await sendMsgToClient(ctx, 0, '', await userinfo.getCharityCodes(50))
        }
    }
    return await sendMsgToClient(ctx, 0, '', await userinfo.getCharityCodes(50))
}

async function getTotalInfo(ctx) {
    let res = await redisUtil.hget('charity:lastest:total', 'total')
    let endTs = 1560528000
    if (res) {
        let ress = JSON.parse(res)
        ress.cntDown = endTs - Math.floor(new Date().getTime() / 1000)
        return sendMsgToClient(ctx, 0, '', ress)
    }
    let result = {
        totalTrx : 0,
        totalBnb : 0,
        totalLtc : 0,
        totaoTickets : 0,
        cntDown : endTs - Math.floor(new Date().getTime() / 1000)
    }
    return sendMsgToClient(ctx, 0, '', result)
}

module.exports = {
    getCharityCodeByAddr,
    getLastCharityCodes,
    getTotalInfo
}