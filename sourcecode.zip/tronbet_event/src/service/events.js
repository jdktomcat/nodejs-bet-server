const usermodel = require('../model/userinfo')
const log4js = require('../configs/log4js.config')
const loggerDefault = log4js.getLogger('print')
const _ = require('lodash')._
const crypto = require("crypto")
const {softswiss, rewards}  = require('../configs/config')
const evnets = require('events')
const common = require('../utils/common')
const actionEvent = new evnets.EventEmitter()
const TronWeb = require('tronweb')
const userinfo = require('../model/userinfo')
const {sha256} = require('js-sha256')
const db = require('../utils/dbUtil')
const poker = require('../utils/poker')
const redisUtil = require('../utils/redisUtil')
const tronUtils = require('../utils/tronUtil')

const startTs  = 1552363200000
const endTs = 1554091200000
const interval = 86400000

async function sendMsgToClient(ctx, errno, errmsg, data) {
    let result = {
        errno : errno,
        errmsg : errmsg,
        data : data
    }
    ctx.body = result
}

async function logs(ctx) {
    let params = ctx.request.body
    let addr = params.addr
    if(!TronWeb.isAddress(addr)) {
        return await sendMsgToClient(ctx, 1001, 'args error', [])
    }
    let res = await userinfo.getLogs(addr)

    return await sendMsgToClient(ctx, 0, '', res)
}

async function bags(ctx) {
    let params = ctx.request.body
    let addr = params.addr

    if(!TronWeb.isAddress(addr)) {
        return await sendMsgToClient(ctx, 1001, 'args error', [])
    }

    let now = new Date().getTime()

    let round = Math.floor((now - startTs) / interval)

    let box = await userinfo.getBoxs(addr)
    let score = await userinfo.getScores(addr, round)
    let bags = await userinfo.getBags(addr)
    let reslt = {bags, score, box}
    return await sendMsgToClient(ctx, 0, '', reslt)
}


async function openBox(ctx) {

    let params = ctx.request.body
    let addr = params.addr
    let num = params.num
    let sign = params.sign

    return await sendMsgToClient(ctx, 1001, 'args error', [])

    try {
        num = Number(num)
    } catch (error) {
        return await sendMsgToClient(ctx, 1001, 'args error', [])
    }

    if (num < 1) {
        return await sendMsgToClient(ctx, 1008, 'args error', [])
    }

    if (! TronWeb.isAddress(addr)) {
        // return await sendMsgToClient(ctx, 1001, 'args error', [])
    }

    let signResult = await tronUtils.verifySignature(sign, addr)
    if (!signResult) {
        return await sendMsgToClient(ctx, 1001, 'sign failed', [])
    }

    let now = new Date().getTime()
    let conn = null
    let gidObj = {}
    try {
        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }

        let {payNum, freeNum} = await userinfo.getDetailBoxs(addr)
        // console.log('payNum, freeNum, num', payNum, freeNum, num)
        if ((payNum + freeNum) <  num) {
            return await sendMsgToClient(ctx, 1008, 'boxes not enough', [])
        }

        if ((payNum + freeNum) <= 0) {
            return await sendMsgToClient(ctx, 1008, 'boxes not enough', [])
        }

        let gids = await common.openBox(addr, freeNum, num)

        gidObj = {}
        gids.map(item => {
            gidObj[item] = (gidObj[item] || 0) + 1
        })

        conn.beginTransaction()
        // 扣箱子
        await userinfo.increaseBox(addr, freeNum, num, conn)
        // 添加日志概览 
        await userinfo.addOverLog(addr, 4, num, now, conn)

        // 添加详细日志, 给用户发牌
        let log_id = await userinfo.getOverviewMaxId(addr, conn)
        for (let gid in gidObj) {
            await userinfo.addDetailLog(log_id, gid, gidObj[gid], conn)
            await userinfo.addUserBag(addr, gid, gidObj[gid], conn)
        }
        conn.commit()

    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        gidObj = {}
        return await sendMsgToClient(ctx, 1008, 'boxes not enough', [])
    } finally {
        if (conn) conn.release()
    }

    let final = []
    for (let one in gidObj) {
        final.push({id : poker.getPoketStyleByGid(one), num : gidObj[one]})
    }
    return await sendMsgToClient(ctx, 0, '', final)
}

async function sell(ctx) {
    let params = ctx.request.body
    let addr = params.addr
    let num = params.num
    let sign = params.sign
    let gid = params.gid
    let now = new Date().getTime()
    return await sendMsgToClient(ctx, 1001, 'args error', [])
    //基本参数检测
    try {
        num = Math.floor(Number(num))
        if (gid == '00') {
            return await sell2To9(ctx)
        } else {
            gid = poker.getGidByPokerStyle(gid)
            if (num <= 0 || gid < 0 || gid > 54) {
                return await sendMsgToClient(ctx, 1001, 'args error', [])
            }
        }
        if (!TronWeb.isAddress(addr)) {
            return await sendMsgToClient(ctx, 1001, 'args error', [])
        }
        let signResult = await tronUtils.verifySignature(sign, addr)
        if (!signResult) {
            return await sendMsgToClient(ctx, 1001, 'sign failed', [])
        }
    } catch (error) {
        return await sendMsgToClient(ctx, 1001, 'args error', [])
    }

    if (gid > 52) {
        return await sendMsgToClient(ctx, 1003, 'joker can not sell', [])
    }

    let price = 0
    if (gid >=0 && gid <= 31) {
        price = 5
    } else if (gid >= 32 && gid <= 51) {
        price = 20
    } else if (gid == 52) {
        price = 100000
    }
    let amount = price * num

    let balance = await tronUtils.getAccBalance()
     
    if (balance < amount) {
        return await sendMsgToClient(ctx, 1004, 'balance not enough, try later please!', [])
    }

    let conn = null
    try {

        let isGidsEnough  = await userinfo.assertSellNumber(addr, num, gid)
        if(!isGidsEnough) {
            return await sendMsgToClient(ctx, 1005, 'poker number not enough!!! check again', [])
        }

        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }


        // 扣除箱子
        conn.beginTransaction()
        await  userinfo.subUserBag(addr, gid, num, conn)
        conn.commit()

    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        return await sendMsgToClient(ctx, 1005, 'poker number not enough', [])
    } finally {
        if (conn) conn.release()
    }

    let tx = await tronUtils.sendTRX(addr, amount)
    if (tx.result != true) {
        console.log('==================> pay failed, infomation : ', {addr, amount})
        return await sendMsgToClient(ctx, 1006, 'pay to user failed!!', [])
    }

    try {
        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }

        
        conn.beginTransaction()
        // 添加日志概览 
        await userinfo.addOverLog(addr, 2, num * price, now, conn)

        // 添加详细日志
        let log_id = await userinfo.getOverviewMaxId(addr, conn)
        await userinfo.addPay2UserLog(addr,  tx.transaction.txID, amount, now, log_id, conn)
        await userinfo.addDetailLog(log_id, gid, num, conn)
        conn.commit()

    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        return await sendMsgToClient(ctx, 1005, 'poker number not enough', [])
    } finally {
        if (conn) conn.release()
    }

    await bags(ctx)

}

async function sell2To9(ctx) {
    return await sendMsgToClient(ctx, 1001, 'args error', [])
    let params = ctx.request.body
    let addr = params.addr
    let num = params.num
    let sign = params.sign
    let now = new Date().getTime()

    //基本参数检测
    try {
        num = Math.floor(Number(num))
        if (!TronWeb.isAddress(addr)) {
            return await sendMsgToClient(ctx, 1001, 'args error', [])
        }
        let signResult = await tronUtils.verifySignature(sign, addr)
        if (!signResult) {
            return await sendMsgToClient(ctx, 1001, 'sign failed', [])
        }
    } catch (error) {
        return await sendMsgToClient(ctx, 1001, 'args error', [])
    }

    let price = 5

    let amount = price * num

    let balance = await tronUtils.getAccBalance()
     
    if (balance < amount) {
        return await sendMsgToClient(ctx, 1004, 'balance not enough, try later please!', [])
    }

    let conn = null
    let gids = {}
    try {

        let isGidsEnough  = await userinfo.assertSpecialSellNumber(addr, num)
        if(!isGidsEnough) {
            return await sendMsgToClient(ctx, 1005, 'poker number not enough!!! check again', [])
        }

        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }


        // 扣除箱子
        conn.beginTransaction()
        let nums = await userinfo.card2To9Nums(addr)
        
        let sumNum = 0
        for (let one of nums) {
            if (one.num == 0) continue
            sumNum += one.num
            if (sumNum >= num) {
                let temNum = one.num - (sumNum - num)
                if (temNum > 0) {
                    gids[one.gid] = temNum
                }
                break
            }
            gids[one.gid] = one.num
        }
        console.log(gids)
        for (let one in gids) {
            await  userinfo.subUserBag(addr, one, gids[one], conn)
        }
        conn.commit()

    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        return await sendMsgToClient(ctx, 1005, 'poker number not enough', [])
    } finally {
        if (conn) conn.release()
    }

    let tx = await tronUtils.sendTRX(addr, amount)
    if (tx.result != true) {
        console.log('==================> pay failed, infomation : ', {addr, amount})
        return await sendMsgToClient(ctx, 1006, 'pay to user failed!!', [])
    }

    try {
        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }

        
        conn.beginTransaction()
        // 添加日志概览 
        await userinfo.addOverLog(addr, 2, num * price, now, conn)

        // 添加详细日志
        let log_id = await userinfo.getOverviewMaxId(addr, conn)
        await userinfo.addPay2UserLog(addr,  tx.transaction.txID, amount, now, log_id, conn)
        
        for (let one in gids) {
            console.log('addr, one, gids[one]-----', addr, one, gids[one])
            await userinfo.addDetailLog(log_id, one, gids[one], conn)
        }
        conn.commit()

    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        return await sendMsgToClient(ctx, 1005, 'poker number not enough', [])
    } finally {
        if (conn) conn.release()
    }

    await bags(ctx)
}

async function exchange(ctx) {
    return await sendMsgToClient(ctx, 1001, 'args error', [])
    let params = ctx.request.body
    let addr = params.addr
    let num = params.num
    let sign = params.sign
    let suitId = params.suit_id
    let now = new Date().getTime()

    console.log(sign)

    //基本参数检测
    try {
        num = Math.floor(Number(num))
        suitId = Math.floor(Number(suitId))
        if (num <= 0 || suitId < 0 || suitId >=9) {
            return await sendMsgToClient(ctx, 1001, 'args error', [])
        }
        if (!TronWeb.isAddress(addr)) {
            return await sendMsgToClient(ctx, 1001, 'args error', [])
        }
        let signResult = await tronUtils.verifySignature(sign, addr)
        if (!signResult) {
            return await sendMsgToClient(ctx, 1001, 'sign failed', [])
        }
    } catch (error) {
        return await sendMsgToClient(ctx, 1001, 'args error', [])
    }

    let gids = await poker.getGidsBySuitId(suitId)

    // 查找补齐五张的牌
    if (gids.length < 5) {
        let randomCard = await userinfo.findA2To9Card(addr)
        if (randomCard < 0) {
            return await sendMsgToClient(ctx, 1001, 'args error', [])
        }

        gids.push(randomCard)
    }

    let isGidsEnough  = await userinfo.assertExchangeNumber(addr, num, gids)
    if(!isGidsEnough) {
        return await sendMsgToClient(ctx, 1005, 'poker number not enough!!! check again', [])
    }

    let price = 0
    let score = 0

    let round = Math.floor((now - startTs) / interval)

    if (suitId <=3) {
        price = 160
        score = 20 * num
    } else if (suitId > 3 && suitId <= 8) {
        price = 100
        score = 10 * num
    }


    let amount = price * num

    let balance = await tronUtils.getAccBalance()
     
    if (balance < amount) {
        return await sendMsgToClient(ctx, 1004, 'balance not enough, try later please!', [])
    }

    let conn = null
    try {
        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }
        // 扣除箱子
        for (let index = 0; index < gids.length; index++) {
            await  userinfo.subUserBag(addr, gids[index], num, conn)
        }

        if (now < endTs) {
            await userinfo.addUserScore(addr, round, score)
        }
        conn.commit()
    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        return await sendMsgToClient(ctx, 1005, 'poker number not enough', [])
    } finally {
        if (conn) conn.release()
    }

    let tx = await tronUtils.sendTRX(addr, amount)
    if (tx.result != true) {
        console.log('==================> pay failed, infomation : ', {addr, amount})
        return await sendMsgToClient(ctx, 1006, 'pay to user failed!!', [])
    }

    try {
        conn = await db.getConnection()
        if (conn == null) {
            return await sendMsgToClient(ctx, 1100, 'Out of serivce, please wait', [])
        }

        conn.beginTransaction()
        // 添加日志概览 
        await userinfo.addOverLog(addr, 3, num * price, now, conn)

        // 添加详细日志
        let log_id = await userinfo.getOverviewMaxId(addr, conn)
        await userinfo.addPay2UserLog(addr,  tx.transaction.txID, amount, now, log_id, conn)

        for (let index = 0; index < gids.length; index++) {
            await userinfo.addDetailLog(log_id, gids[index], num, conn)
        }
        conn.commit()

    } catch (error) {
        console.log(error)
        if (conn) conn.rollback()
        return await sendMsgToClient(ctx, 1005, 'poker number not enough', [])
    } finally {
        if (conn) conn.release()
    }
    await bags(ctx)
}

async function rank(ctx) {
    let params = ctx.request.body
    let addr = params.addr
    let now = new Date().getTime()
    let round = Math.floor((now - startTs) / interval)
    let allRank = await userinfo.allRank(round, 50)
    let meScore = await userinfo.meScore(addr, round)
    let meRank = await userinfo.meRank(addr, round)
    let meRward = 0

    if (!TronWeb.isAddress(addr)) {
        addr = 'abc'
    }


    let meName = addr

    let final = []

    for (let i = 0;i< allRank.length; i++){
        let name = allRank[i].addr
        let _name = await redisUtil.hget("player:info:" + name, "name")
        if (_name && _name != '') {
            name = _name;
        }

        if (addr == allRank[i].addr) {
            meRank = i + 1
            meName = name
            meRward = rewards[i]
        }
        let tmp = {
            rank : i + 1,
            reward : rewards[i],
            name : name,
            score :allRank[i].score,
            addr : allRank[i].addr
        }

        final.push(tmp)
    }

    let _name = await redisUtil.hget("player:info:" + meName, "name")
    if (_name && _name != '') {
        meName = _name;
    }

    if (allRank.length < 50) {
        let tmpLength = allRank.length
        for (let i=0; i< 50 - tmpLength; i++){
            final.push({rank : tmpLength + 1 + i, score : 0, addr : '-', reward : rewards[tmpLength + i], name : '-'})
        }
    }
    return await sendMsgToClient(ctx, 0, '', {rank : final, me : {rank : meRank || '-', reward :meRward, name : meName, score : meScore, addr : addr == 'abc' ? '-' : addr}})
}

async function totalRank(ctx) {
    let params = ctx.request.body
    let addr = params.addr
    let now = new Date().getTime()
    let allRank = await userinfo.allTotalRank(20)
    let meScore = await userinfo.meTotalScore(addr)
    let meRank = '-'
    let meRward = 0

    if (!TronWeb.isAddress(addr)) {
        addr = 'abc'
    }

    let meName = addr

    let final = []

    for (let i = 0;i< allRank.length; i++){
        let name = allRank[i].addr
        let _name = await redisUtil.hget("player:info:" + name, "name")
        if (_name && _name != '') {
            name = _name;
        }

        if (addr == allRank[i].addr) {
            meRank = i + 1
            meName = name
            meRward = 0
        }
        let tmp = {
            rank : i + 1,
            reward : i == 0 ? 'tsla' : 0,
            name : name,
            score :allRank[i].score,
            addr : allRank[i].addr
        }

        final.push(tmp)
    }

    let _name = await redisUtil.hget("player:info:" + meName, "name")
    if (_name && _name != '') {
        meName = _name;
    }

    return await sendMsgToClient(ctx, 0, '', {rank : final, me : {rank : meRank || '-', reward :meRward, name : meName, score : meScore, addr : addr == 'abc' ? '-' : addr}})
}

async function luckers(ctx) {
    let joker101 = await redisUtil.hget('event:poker:info', 'luckyUsers')
    let joker100 = await redisUtil.hget('event:poker:info', 'joker100')
    try {
        if (joker101) {
            joker101 = JSON.parse(joker101)
        } else {
            joker101 = []
        }

        if (joker100) {
            joker100 = JSON.parse(joker100)
        } else {
            joker100 = []
        }

    } catch (error) {
        console.log(error)
        joker101 = []
        joker100 = []
    }

    let joker100Rs = []
    let joker101Rs = []
    for (let one of joker100) {
      let name = await redisUtil.hget('player:info:' + one.addr, 'name')
      let tmp = {
          name : one.addr,
          addr : one.addr,
          ts : one.ts
      }
      if (name) {
        tmp.name = name
      }
      joker100Rs.push(tmp)
    }

    for (let one of joker101) {
        let name = await redisUtil.hget('player:info:' + one.addr, 'name')
        let tmp = {
            name : one.addr,
            addr : one.addr,
            ts : one.ts
        }
        if (name) {
          tmp.name = name
        }
        joker101Rs.push(tmp)
    }
    
    sendMsgToClient(ctx, 0, '', {'joker100' : joker100Rs, 'joker101' : joker101Rs})
    
}


var events = {
    startTs,
    interval,
    logs,
    bags,
    openBox,
    sell,
    exchange,
    rank,
    totalRank,
    luckers,
}

module.exports = events