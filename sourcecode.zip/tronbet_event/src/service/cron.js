const usermodel = require('../model/userinfo')
const log4js = require('../configs/log4js.config')
const loggerDefault = log4js.getLogger('print')
const _ = require('lodash')._
const crypto = require("crypto")
const {softswiss, rewards}  = require('../configs/config')
const evnets = require('events')
const common = require('../utils/common')
const cronEvent = new evnets.EventEmitter()
const TronWeb = require('tronweb')
const userinfo = require('../model/userinfo')
const {sha256} = require('js-sha256')
const db = require('../utils/dbUtil')
const poker = require('../utils/poker')
const redisUtil = require('../utils/redisUtil')
const tronUtils = require('../utils/tronUtil')
const {startTs, interval} = require('./events')



cronEvent.on('dailyRankReward', () => {
    let timer = setInterval(async () => {
        let now = new Date().getTime()
        
        let newRound =  Math.floor((now - startTs) / interval)
        let lastRound = await userinfo.maxRewardRound()
        console.log(lastRound, newRound)

        return

        if (newRound - lastRound <= 1) {
            console.log('not in reward time, check it...')
            return console.log('try next time, ~~~~~~~~~~~~~~~~')
        }

        let result = await userinfo.allRank(newRound - 1, 50)

        console.log(result)

        let wardconf = rewards

        let conn = null
        //快照数据放入日志
        try {
            conn = await db.getConnection()
            if (conn == null) {
                return console.error('Shit, get db connection failed!!!!!!!!!!!!!!')            }
            conn.beginTransaction()
            for (let index = 0; index < result.length ; index++) {
                await userinfo.addDailyRankWardLog(newRound - 1, result[index].addr, result[index].score, 0, wardconf[index], now, conn)
            }
            conn.commit()
        } catch (error) {
            console.log(error)
            if(conn) conn.rollback()
        } finally {
            if(conn) conn.release()
        }

        // 开始发奖
        for (let index = 0; index < result.length ; index++) {
            console.log('result[index].addr, wardconf[index]=======>', result[index].addr, wardconf[index])
            try {
                let tx = await tronUtils.sendTRX(result[index].addr, wardconf[index])
                console.log(tx)
                if (tx.result == true) {
                    await userinfo.updateTxidToDailyRankWardLog(newRound - 1, result[index].addr,  tx.transaction.txID)
                }
                
            } catch (error) {
                console.log(error)
            }
        }
        console.log('send daily rank success, lalalalalalala!!!')
    }, 2400000);
})

let lastestTimer = setInterval(async () => {
    let res = await userinfo.getCharityCodes(50)
    if (res) await redisUtil.hset('charity:lastest:rank', 'rank', JSON.stringify(res))

    let totalInfo = await userinfo.getTotalInfo()
    let totalCnt = await userinfo.getTotalTicks()

    let result = {
        totalTrx : 0,
        totalBnb : 0,
        totalLtc : 0,
        totaoTickets : totalCnt,
        cntDown : 1560528000 - Math.floor(new Date().getTime() / 1000)
    }
    for (let one of totalInfo) {
        if (one.coinType == 'trx') {
            result.totalTrx = one.amount
        } else if (one.coinType == 'bnb') {
            result.totalBnb = one.amount
        } else if (one.coinType == 'ltc') {
            result.totalLtc = one.amount
        }
    }

    await redisUtil.hset('charity:lastest:total', 'total', JSON.stringify(result))
}, 120000);


module.exports = {cronEvent}