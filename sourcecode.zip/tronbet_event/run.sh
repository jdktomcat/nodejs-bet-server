#!/bin/bash
node index.js