#!/bin/bash
npm run start