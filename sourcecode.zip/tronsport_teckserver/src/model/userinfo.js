const db = require('../utils/dbUtil')
const _ = require('lodash')._
const tranStatus = require('../configs/config').tranStatus

const dividendsDuration = 86400
const daystart = 18005

async function getUserBalance(addr, types) {
    let sql = "select round(trx / 1000000, 3) as trx from live_user where addr = ?"
    if (types == 'btt') {
        sql = "select round(btt / 1000000, 3) as trx from live_user where addr = ?"
    } else if (types == 'win') {
        sql = "select round(wink / 1000000, 3) as trx from live_user where addr = ?"
    }
    let res = await db.exec(sql, [addr])
    if (!_.isEmpty(res)) {
        return res[0].trx
    }
    return null
}

async function getUserBalanceBySportsSession(sessionId, types) {
    let sql = "select round(trx / 1000000, 3) as trx from live_user where sportsSession = ?"
    if (types == 'btt') {
        sql = "select round(btt / 1000000, 3) as trx from live_user where sportsSession = ?"
    } else if (types == 'win') {
        sql = "select round(wink / 1000000, 3) as trx from live_user where sportsSession = ?"
    }
    let res = await db.exec(sql, [sessionId])
    if (!_.isEmpty(res)) {
        return res[0].trx
    }
    return null
}

async function userRegister(addr, nickName) {
    let sql = "insert into live_user(addr, nickName) values (?, ?)"
    let res = await db.exec(sql, [addr, nickName])
    return res
}

async function userLoginLog(addr) {
    let now = new Date().getTime()
    let sql = "insert into live_login_log(addr, ts) values(?,?)"
    let res = await db.exec(sql, [addr, now])
    return res
}

async function getUserByKey(key) {
    let sql = "select * from live_user where userKey = ? limit 1"
    let res = await db.exec(sql, [key])
    return res
}

async function updateSportsSessionByKey(sessionId, key) {
    let now = new Date().getTime()
    let sql = "update live_user set sportsSession = ? where userKey = ?"
    let res = await db.exec(sql, [sessionId, key])
    return res
}

async function updateSessionId(addr, sessionId) {
    let now = new Date().getTime()
    let sql = "update live_user set sessionId = ?, loginTs = ? where addr = ?"
    let res = await db.exec(sql, [sessionId, now, addr])
    return res
}

async function userBet(tsp, blp, conn) {

    //update balance
    let updateSql = "update live_user set trx = trx - ? where addr = ?"

    await db.execTrans(updateSql, [tsp.amount, tsp.addr], conn)

    let transSql = "insert into sports_transaction_log(addr, transactionId, betslipId, ts, status, amount, crossRateEuro, action, currency) \
                                values(?,?,?,?,?,?,?,?,?)"
    await db.execTrans(transSql, [tsp.addr, tsp.transactionId, tsp.betslipId, tsp.ts, tsp.status, tsp.amount, tsp.crossRateEuro, tsp.action, tsp.currency], conn)
    
    let betLogSql = "insert into sports_bet_detail_log(addr, transactionId, betslipId, currency, sumAmount, types, betK, betId, sportId, eventId, tournamentId, \
        categoryId, live, competitorName, outcomeName, scheduled, odds) values ?"
    
    let blparmas = []
    for (let one of blp) {
        blparmas.push([one.addr, one.transactionId, one.betslipId, one.currency, one.sumAmount, one.types, one.betK, one.betId, one.sportId, one.eventId, 
            one.tournamentId, one.categoryId, one.live, one.competitorName, one.outcomeName, one.scheduled, one.odds])
    }
    await db.execTrans1(betLogSql, [blparmas], conn)
}

async function userRefund(params, conn) {

    let updateSql = "update live_user set trx = trx + ? where addr = ?"
    await db.execTrans(updateSql, [params.amount, params.addr], conn)

    let updateTransactionSql = "update sports_transaction_log set status = ? where transactionId = ? and addr = ? and status <> ? and status <> ?"
    await db.execTrans(updateTransactionSql, [tranStatus.refund, params.betTransactionId, params.addr, tranStatus.refund, tranStatus.rollback], conn)

    let addLogSql = "insert into sports_result_log(addr, transactionId, betTransactionId, betslipId, ts, status, amount, action, currency) values (?,?,?,?,?,?,?,?,?)"
    await db.execTrans(addLogSql, [params.addr, params.transactionId, params.betTransactionId, 
        params.betslipId, params.ts, params.status, params.amount, params.action, params.currency], conn)
}

async function userWin(params, conn) {
    let updateSql = "update live_user set trx = trx + ? where addr = ?"
    await db.execTrans(updateSql, [params.amount, params.addr], conn)

    let updateTransactionSql = "update sports_transaction_log set status = ?, win = ? where transactionId = ? and addr = ?"
    await db.execTrans(updateTransactionSql, [tranStatus.win, params.amount, params.betTransactionId, params.addr], conn)

    let addLogSql = "insert into sports_result_log(addr, transactionId, betTransactionId, betslipId, ts, status, amount, action, currency) values (?,?,?,?,?,?,?,?,?)"
    await db.execTrans(addLogSql, [params.addr, params.transactionId, params.betTransactionId, 
        params.betslipId, params.ts, params.status, params.amount, params.action, params.currency], conn)
}

async function userCancel(params, conn) {
    let updateSql = "update live_user set trx = trx - ? where addr = ?"
    await db.execTrans(updateSql, [params.amount, params.addr], conn)

    let updateTransactionSql = "update sports_transaction_log set status = ? where transactionId = ? and addr = ? and status = ?"
    await db.execTrans(updateTransactionSql, [tranStatus.cancel, params.betTransactionId, params.addr, tranStatus.win], conn)

    let addLogSql = "insert into sports_result_log(addr, transactionId, betTransactionId, betslipId, ts, status, amount, action, currency, reason) values (?,?,?,?,?,?,?,?,?,?)"
    await db.execTrans(addLogSql, [params.addr, params.transactionId, params.betTransactionId, 
        params.betslipId, params.ts, params.status, params.amount, params.action, params.currency, params.reason], conn)
}

async function userBetSettle(tronsactionId, state) {
    let now = new Date().getTime()
    let sql = "update sports_transaction_log set status = ?, ts = ? where transactionId = ?"
    let status = -1 
    if (state == 'win') {
        status = tranStatus.win
    } else if (state == 'lost') {
        status = tranStatus.lost
    } else if (state == 'refund') {
        status = tranStatus.refund
    } else if (state == 'cancel') {
        status = tranStatus.cancel
    } else if (state == 'rollback') {
        status = tranStatus.rollback
    }
    await db.exec(sql, [status, now, tronsactionId])
}

async function userRollBack(params, conn) {
    let updateSql = "update live_user set trx = trx - ? where addr = ?"
    await db.execTrans(updateSql, [params.amount, params.addr], conn)

    let updateTransactionSql = "update sports_transaction_log set status = ? where transactionId = ? and addr = ?"
    await db.execTrans(updateTransactionSql, [tranStatus.rollback, params.betTransactionId, params.addr], conn)

    let addLogSql = "insert into sports_result_log(addr, transactionId, betTransactionId, betslipId, ts, status, amount, action, currency, reason) values (?,?,?,?,?,?,?,?,?,?)"
    await db.execTrans(addLogSql, [params.addr, params.transactionId, params.betTransactionId, 
        params.betslipId, params.ts, params.status, params.amount, params.action, params.currency, params.reason], conn)

}

async function getTransactionById(transactionId) {
    let sql = "select * from sports_transaction_log where transactionId = ?"
    return await db.exec(sql, [transactionId])
}

async function getTransactionByIdAndStatus(transactionId, status) {
    let sql = "select * from sports_transaction_log where transactionId = ? and status = ?"
    return await db.exec(sql, [transactionId, status])
}

async function withdraw(addr, amount, orderId, conn) {
    let sql = "update live_user set trx = trx - ? where addr = ?"
    let res1 = await db.execTrans(sql, [amount, addr], conn)

    let now = new Date().getTime()
    let logSql = "insert into live_withdraw_log(orderId, addr, amount, startTs) values (?,?,?,?)"
    let logres = await db.execTrans(logSql, [orderId, addr, amount, now], conn)
    return logres
}

async function finishedWithdrawLog(addr, txId, orderId) {
    let sql = "update live_withdraw_log set txId = ?, endTs = ? where orderId = ? and addr = ?"
    let now = new Date().getTime()
    let res = await db.exec(sql, [txId, now, orderId, addr])
    return res
}

async function findTodayWithdrawTimes(addr) {
    let now = new Date().getTime()
    let zeroTime = 1551283200000
    let todayStime = now - ((now - zeroTime) % 86400000)
    let sql = "select count(1) cnt from live_withdraw_log where addr = ? and startTs >= ?"
    let res = await db.exec(sql, [addr, todayStime])
    return res[0].cnt
}

async function getAccountBySessionId(sessionId) {
    let sql = "select * from live_user where sessionId = ?"
    let res = await db.exec(sql, [sessionId])
    return res
}

async function getUserActionLog(adrr, actionId) {
    let sql = "select * from live_action_log where addr = ? and actionId = ?"
    let res = await db.exec(sql, [addr, actionId])
    return res
}

async function generateFreespins(addr, issuseId, exprTs, num, status) {
    let sql = "insert into live_freespins(addr, issuseId, exprTs, num, status, ts) values(?,?,?,?,?,?)"
    let now = new Date().getTime()
    let res = await db.exec(sql, [addr, issuseId, exprTs, num, status, now])
    return res
}

async function cancelFreespins(issuseId) {
    let sql = "update live_freespins set status = 'canceled', ts = ? where issuseId = ?"
    let now = new Date().getTime()
    let res = await db.exec(sql, [now, issuseId])
    return res
}


async function getUserIdByIssuseId(issuseId) {
    let sql = "select addr from live_freespins where issuseId = ?"
    let res = await db.exec(sql, [issuseId])
    return res
}

async function getRealTimeProfitAmount(ts) {
    let startTs = (Math.floor(ts / dividendsDuration)) * dividendsDuration * 1000
    let endTs = ts * 1000
    let sql = "select sum(Amount) amount from tron_live.live_action_log where ts >= ? and ts < ? and action = ? and txStatus = 1"
    let betAmount = await db.exec(sql, [startTs, endTs * 10, 'bet'])
    let resultAmount = await db.exec(sql, [startTs, endTs * 10, 'result'])

    let lastDay = Math.floor(ts / dividendsDuration) - 1
    if (lastDay >= 0) {
        let hasYestodayProfit = await hasLastDayProfit(lastDay)
        if (!hasYestodayProfit) {
            // 插入
            
            let lastBetAmount = await db.exec(sql, [startTs - 86400000, startTs, 'bet'])
            let lastResultAmount = await db.exec(sql, [startTs - 86400000, startTs, 'result'])

            if (_.isEmpty(lastBetAmount)) {
                lastBetAmount = 0
            } else {
                lastBetAmount = lastBetAmount[0].amount || 0
            }

            if (_.isEmpty(lastResultAmount)) {
                lastResultAmount = 0
            } else {
                lastResultAmount = lastResultAmount[0].amount || 0
            }


            console.log('=====startTs,lastBetAmount,lastResultAmount=====',startTs,lastBetAmount,lastResultAmount)
            await insertLastDay(lastDay, lastBetAmount - lastResultAmount)
        }
    }

    let lastTotalProfit = await getHistDaysProfit()

    if (!_.isEmpty(betAmount)) {
        betAmount = betAmount[0].amount || 0
    } else {
        betAmount = 0
    }

    if (!_.isEmpty(resultAmount)) {
        resultAmount = resultAmount[0].amount || 0
    } else {
        resultAmount = 0
    }

    // console.log('lastTotalProfit,totalDividends ++++>', lastTotalProfit,totalDividends)
    let totalDividends = await getDividendsAmount()
    console.log('lastTotalProfit - totalDividends + betAmount - resultAmount ====>', Number(lastTotalProfit),totalDividends,betAmount,resultAmount)

    return Number(lastTotalProfit) - Number(totalDividends) +  Number(betAmount) - Number(resultAmount)
}
async function insertLastDay(day, amount) {
    let sql = "insert into live_profit_log(days, profit) values(?,?)"
    let res = await db.exec(sql, [day, amount * 1e6])
    return res
}

async function hasLastDayProfit(day) {
    let sql = "select profit from live_profit_log where days = ?"
    let res = await db.exec(sql, [day])
    if (_.isEmpty(res)) return false
    return true
}

async function getHistDaysProfit() {
    let sql = "select sum(profit / 1000000) profit from live_profit_log"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].profit || 0
}

async function getDividendsAmount() {
    let sql = "select sum(total_trx / 1000000 + rank_trx / 1000000) trx from live_div_info"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].trx || 0
}

async function getUserWithDrawStatus(addr, orderId) {
    let sql = "select startTs from live_withdraw_log where orderId = ? and addr = ?"
    let res = await db.exec(sql, [orderId, addr])
    return res
}

async function getAmountRankData(round) {
    let sql = "select addr, amount / 1000000 amount from live_bet_info where round = ? order by amount desc limit 20"
    let res = await db.exec(sql, [round])
    return res
}

async function getProfitRankData(round) {
    let sql = "select addr, win / 1000000 amount from live_bet_info where round = ? order by win desc limit 20"
    let res = await db.exec(sql, [round])
    return res
}

async function getRankBonus(startTs) {
    let sql = "select sum(rank_trx / 1000000) amount from live_div_info where send_ts >= ?"
    let res = await db.exec(sql, [startTs])
    if (_.isEmpty(res)) return 0
    return res[0].amount || 0
}

async function maxAmountRewardRound() {
    let sql = "select max(round) maxRound from live_amount_rank_log"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].maxRound || 0
}

async function maxPayoutRewardRound() {
    let sql = "select max(round) maxRound from live_payout_rank_log"
    let res = await db.exec(sql, [])
    if (_.isEmpty(res)) return 0
    return res[0].maxRound || 0
}

async function addAmountRankWardLog(round, addr, amount, wardAmount, ts, conn) {
    console.log('------round, addr, amount, wardAmount, ts, ------', round, addr, amount, wardAmount, ts)
    let sql = "insert into live_amount_rank_log(round, addr, amount, wardAmount, ts) values(?,?,?,?,?)"
    let res = await db.execTrans(sql, [round, addr, amount, wardAmount, ts], conn)
    return res
}

async function addPayoutRankWardLog(round, addr, amount, wardAmount, ts, conn) {
    console.log('------round, addr, amount, wardAmount, ts, ------', round, addr, amount, wardAmount, ts)
    let sql = "insert into live_payout_rank_log(round, addr, amount, wardAmount, ts) values(?,?,?,?,?)"
    let res = await db.execTrans(sql, [round, addr, amount, wardAmount, ts], conn)
    return res
}

async function updateTxidToAmountRankWardLog(round, addr, txId) {
    let sql = "update live_amount_rank_log set txId = ? where round = ? and addr = ?"
    let res = await db.exec(sql, [txId, round, addr])
    return res
}

async function updateTxidToPayoutRankWardLog(round, addr, txId) {
    let sql = "update live_payout_rank_log set txId = ? where round = ? and addr = ?"
    let res = await db.exec(sql, [txId, round, addr])
    return res
}

async function getLastDividends(startTs) {
    let sql = "select total_trx * 0.15 trx, send_ts ts, 'LIVE' types from tron_live.live_div_info where send_ts >= ? union all select total_trx * 0.15 trx, send_ts ts, 'RAKE' types from tronbet_poker_log.rake_div_info where send_ts >=?"
    let res = await db.exec(sql, [startTs, startTs])
    return res
}

async function getFreespinNum(addr) {
    let sql = 'select fsNum from live_freespin_user where addr = ?'
    let res = await db.exec(sql, [addr])
    if(_.isEmpty(res)) return 0
    return res[0].fsNum
}

async function addFreeSpinUser(addr,nickName, userId, num) {
    let num = await getFreespinNum(addr)
    if (num >= 20) return
    let sql = "insert into live_freespin_user(addr, nickName, emUserId, fsNum) values(?,?,?,?) on DUPLICATE KEY UPDATE fsNum = fsNum + ?"
    let res = await db.exec(sql, [addr, nickName, userId, num, num])
    return res
}

async function addFressSpinLog(addr, orderId, endTs, ts) {
    let sql = 'insert into live_freespin_log(addr, orderId, endTs, ts) values(?,?,?,?)'
    let res = await db.exec(sql, [addr, orderId, endTs, ts])
    return res
}

module.exports = {
    getUserBalance,
    userRegister,
    userLoginLog,
    updateSessionId,
    getUserBalanceBySportsSession,
    userBet,
    userRollBack,
    withdraw,
    finishedWithdrawLog,
    findTodayWithdrawTimes,
    getAccountBySessionId,
    getUserActionLog,
    generateFreespins,
    cancelFreespins,
    getUserIdByIssuseId,
    getTransactionById,
    getRealTimeProfitAmount,
    getUserWithDrawStatus,
    getAmountRankData,
    getProfitRankData,
    getRankBonus,
    maxAmountRewardRound,
    maxPayoutRewardRound,
    addAmountRankWardLog,
    addPayoutRankWardLog,
    updateTxidToAmountRankWardLog,
    updateTxidToPayoutRankWardLog,
    getLastDividends,
    userRefund,
    userBetSettle,
    userWin,
    userCancel,
    getTransactionByIdAndStatus,
    getUserByKey,
    updateSportsSessionByKey
}