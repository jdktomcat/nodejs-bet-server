const usermodel = require('../model/userinfo')
const redisUtil = require('../utils/redisUtil')
const user = require('./user')
const {app}  = require('../configs/config')
const db = require('../utils/dbUtil')
const tronUtil = require('../utils/tronUtil')
const _ = require('lodash')._
const axios = require('axios')

const RankInitTs = app.RankInitTs
