const userinfo = require('../model/userinfo')
const db = require('../utils/dbUtil')
const log4js = require('../configs/log4js_config')
const logger = log4js.getLogger('print')
const _ = require('lodash')._
const {tranStatus}  = require('../configs/config')
const common = require('../utils/common')
const {errorCode} = require('../utils/errCode')

let LocalCurrency = "TRX"
// LocalCurrency = 'NOK'

function sendSuccessMessage2Client(ctx, httpcode, data) {
    if (httpcode != 403) httpcode = 200
    if (!data) data = {}
    let result = {
        ...data
    }
    ctx.status = httpcode  //http状态吗， 正常情况下是200， 异常情况返回403
    ctx.body = result
}

function sendErrorMessage2Client(ctx, httpcode, errno) {
    let result = {
        code : errno || 0,
        message : errorCode[errno] || '',
    }
    ctx.status = httpcode  //http状态吗， 正常情况下是200， 异常情况返回403
    ctx.body = result
}



async function ping(ctx) {
    let now = Math.floor(new Date().getTime() / 1000)
    return sendErrorMessage2Client(ctx, 200, 0, now)
}


async function identify(ctx) {
    let params = ctx.request.body || ctx.request.query
    let querys = ctx.request.query

    let jwtToken = params.payload

    let key = querys.key
    let ip = querys.ip
    let uacode = querys.uacode

    console.log({key, ip, uacode})

    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)

        let user = await userinfo.getUserByKey(key)
        if (_.isEmpty(user)) return sendErrorMessage2Client(ctx, 403, 1001)

        let sessionId = common.getRandomSeed(64)
        if (user[0].sportsSession == null || user[0].sportsSession.length < 40) {
            await userinfo.updateSportsSessionByKey(sessionId, key)
        } else {
            sessionId = user[0].sportsSession
        }

        let result = {
            user_id : user[0].addr,
            username : user[0].nickName || user[0].addr,
            lang : 'EN',
            currency : 'TRX',
            balance : Math.floor(user[0].balance / 1e4),
            feature_flags: {
                is_cashout_available: true
            },
            session_id : sessionId
        }
        return sendSuccessMessage2Client(ctx, 200, result)

    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }


}

async function betMake(ctx) {
    //@TODO
    let params = ctx.request.body || ctx.request.query
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)

        let datas = checkKey.payload
        let currency = datas.currency
        let addr = datas.player_id
        let amount = datas.amount / 100   // 100
        let sessionId = datas.session_id

        if (amount <= 0) return sendErrorMessage2Client(ctx, 400, 2001)  // 下注必须是正数金额

        let userBalance = await userinfo.getUserBalanceBySportsSession(sessionId, currency)
        if (userBalance == null) return sendErrorMessage2Client(ctx, 400, 1007) // session过期
        if (userBalance < amount) return sendErrorMessage2Client(ctx, 400, 2001) //余额不足

        
        let transactionParams = {
            addr: datas.player_id,
            transactionId: datas.transaction.id,
            betslipId: datas.transaction.betslip_id,
            ts: Math.floor(datas.transaction.timestamp * 1000),
            status: datas.transaction.status,
            amount: datas.amount * 1e4,
            crossRateEuro: datas.transaction.cross_rate_euro,
            action: datas.transaction.operation,
            currency: datas.currency
        }

        let betLogParams = []
        for (let one of datas.betslip.bets) {
            let tmp = {
                addr: datas.player_id,
                transactionId: datas.transaction.id,
                betslipId: datas.transaction.betslip_id,
                currency: datas.currency,
                types: datas.betslip.type,
                betK: datas.betslip.k,
                sumAmount: datas.amount * 1e4,
                betId: one.id,
                sportId: one.sport_id,
                eventId: one.event_id,
                tournamentId: one.tournament_id,
                categoryId: one.category_id,
                live: one.live,
                competitorName: one.competitor_name.join('::'),
                outcomeName: one.outcome_name,
                scheduled: one.scheduled,
                odds: one.odds,
            }
            betLogParams.push(tmp)
        }

        console.log(datas.player_id, ' make bet@', datas.transaction.id, 'amount ===>', Math.floor(datas.amount / 100) )
        let conn = null
        
        try {
            conn = await db.getConnection()
            if (conn == null) {
                return await sendErrorMessage2Client(ctx, 403, 204)
            }
            conn.beginTransaction()
            await userinfo.userBet(transactionParams, betLogParams, conn)
            conn.commit()
        } catch (error) {
            console.log('======================rollback=======================')
            logger.info(error)
            if (conn) conn.rollback()
            if (conn) conn.release()
            return await sendErrorMessage2Client(ctx, 400, 2004)
        } finally {
            if (conn) conn.release()
        }

        let newBalance = await userinfo.getUserBalanceBySportsSession(sessionId, currency)
        let result = {
            id: datas.transaction.id,
            ext_transaction_id: datas.transaction.id,
            parent_transaction_id: null,
            user_id: addr,
            operation: "bet",
            amount: datas.amount,
            currency: datas.currency,
            balance: Math.floor(newBalance * 1e2)
        }
        console.log(result)
        return sendSuccessMessage2Client(ctx, 200, result)
    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }


}

async function betCommit(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        console.log(checkKey)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
    } catch (error) {
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
    return sendSuccessMessage2Client(ctx, 200)
    //@TODO
}

async function betSettlement(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
        let datas = checkKey.payload
        await userinfo.userBetSettle(datas.bet_transaction_id, datas.status)
        return sendSuccessMessage2Client(ctx, 200)
    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
    //@TODO
}

async function betRefund(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
        
        let datas = checkKey.payload
        let transactionParams = {
            addr: datas.transaction.ext_player_id,
            transactionId: datas.transaction.id,
            betTransactionId: datas.bet_transaction_id,
            betslipId: datas.transaction.betslip_id,
            ts: Math.floor(datas.transaction.timestamp * 1000),
            status: datas.transaction.status,
            amount: datas.transaction.amount * 1e4,
            action: datas.transaction.operation,
            currency: datas.transaction.currency
        }

        console.log(transactionParams.addr, 'bet refund@', transactionParams.transactionId, 'betId ===>', transactionParams.betTransactionId)
        let transaction = await userinfo.getTransactionById(datas.bet_transaction_id)
        if (_.isEmpty(transaction) || transaction[0].addr != transactionParams.addr || transaction[0].amount != transactionParams.amount) {
            return sendErrorMessage2Client(ctx, 400, 2003)
        }

        if (transaction[0].status == tranStatus.refund || transaction[0].status == tranStatus.rollback) {
            return sendErrorMessage2Client(ctx, 400, 2004)
        }

        let conn = null
        try {
            conn = await db.getConnection()
            if (conn == null) {
                return await sendErrorMessage2Client(ctx, 403, 204)
            }
            conn.beginTransaction()
            await userinfo.userRefund(transactionParams, conn)
            conn.commit()
        } catch (error) {
            console.log('======================rollback=======================')
            logger.info(error)
            if (conn) conn.rollback()
            if (conn) conn.release()
            return await sendErrorMessage2Client(ctx, 400, 2004)
        } finally {
            if (conn) conn.release()
        }

        let newBalance = await userinfo.getUserBalance(transactionParams.addr, transactionParams.currency)
        let result = {
            id: datas.transaction.id,
            ext_transaction_id: datas.transaction.id,
            parent_transaction_id: datas.bet_transaction_id,
            user_id: transactionParams.addr,
            operation: "refund",
            amount: transactionParams.amount,
            currency: transactionParams.currency,
            balance: Math.floor(newBalance * 1e2)
        }
        return sendSuccessMessage2Client(ctx, 200, result)
        
    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
    //@TODO
}

async function betWin(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
        
        let datas = checkKey.payload
        let transactionParams = {
            addr: datas.transaction.ext_player_id,
            transactionId: datas.transaction.id,
            betTransactionId: datas.bet_transaction_id,
            betslipId: datas.transaction.betslip_id,
            ts: Math.floor(datas.transaction.timestamp * 1000),
            status: datas.transaction.status,
            amount: datas.amount * 1e4,
            action: datas.transaction.operation,
            currency: datas.transaction.currency
        }

        console.log(transactionParams.addr, 'bet win@', transactionParams.transactionId, 'betId ===>', transactionParams.betTransactionId, 
        'win amount ===>', Math.floor(transactionParams.amount / 1e6))
        let transaction = await userinfo.getTransactionById(datas.bet_transaction_id)
        if (_.isEmpty(transaction) || transaction[0].addr != transactionParams.addr) {
            return sendErrorMessage2Client(ctx, 400, 2003)
        }

        // 状态在取消, 输赢的状态下, 是不能再次调用win的奖励的
        if (transaction[0].status == tranStatus.cancel || transaction[0].status == tranStatus.win || transaction[0].status == tranStatus.lost) {
            return sendErrorMessage2Client(ctx, 400, 2004)
        }

        let conn = null
        try {
            conn = await db.getConnection()
            if (conn == null) {
                return await sendErrorMessage2Client(ctx, 403, 204)
            }
            conn.beginTransaction()
            await userinfo.userWin(transactionParams, conn)
            conn.commit()
        } catch (error) {
            console.log('======================rollback=======================')
            logger.info(error)
            if (conn) conn.rollback()
            if (conn) conn.release()
            return await sendErrorMessage2Client(ctx, 400, 2004)
        } finally {
            if (conn) conn.release()
        }

        let newBalance = await userinfo.getUserBalance(transactionParams.addr, transactionParams.currency)
        let result = {
            id: datas.transaction.id,
            ext_transaction_id: datas.transaction.id,
            parent_transaction_id: datas.bet_transaction_id,
            user_id: transactionParams.addr,
            operation: "win",
            amount: transactionParams.amount,
            currency: transactionParams.currency,
            balance: Math.floor(newBalance * 1e2)
        }
        return sendSuccessMessage2Client(ctx, 200, result)
        
    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
    //@TODO
}

async function betCancel(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
        let datas = checkKey.payload
        let transactionParams = {
            addr: datas.transaction.ext_player_id,
            transactionId: datas.transaction.id,
            betTransactionId: datas.bet_transaction_id,
            betslipId: datas.transaction.betslip_id,
            ts: Math.floor(datas.transaction.timestamp * 1000),
            reason: datas.reason,
            status: datas.transaction.status,
            amount: datas.transaction.amount * 1e4,
            action: datas.transaction.operation,
            currency: datas.transaction.currency
        }

        console.log(transactionParams.addr, 'bet cancel@', transactionParams.transactionId, 'betId ===>', transactionParams.betTransactionId)
        let transaction = await userinfo.getTransactionByIdAndStatus(datas.bet_transaction_id, 50)
        if (_.isEmpty(transaction) || transaction[0].addr != transactionParams.addr) {
            return sendErrorMessage2Client(ctx, 400, 2003)
        }

        // 只有赢了的订单会取消, 其他情况的取消, 都是调用的refund
        if (transaction[0].status != tranStatus.win) {
            return sendErrorMessage2Client(ctx, 400, 2004)
        }

        let conn = null
        try {
            conn = await db.getConnection()
            if (conn == null) {
                return await sendErrorMessage2Client(ctx, 403, 204)
            }
            conn.beginTransaction()
            console.log(transactionParams)
            await userinfo.userCancel(transactionParams, conn)
            conn.commit()
        } catch (error) {
            console.log('======================rollback=======================')
            logger.info(error)
            if (conn) conn.rollback()
            if (conn) conn.release()
            return await sendErrorMessage2Client(ctx, 400, 2004)
        } finally {
            if (conn) conn.release()
        }

        let newBalance = await userinfo.getUserBalance(transactionParams.addr, transactionParams.currency)
        let result = {
            id: datas.transaction.id,
            ext_transaction_id: datas.transaction.id,
            parent_transaction_id: datas.bet_transaction_id,
            user_id: transactionParams.addr,
            operation: transactionParams.action,
            amount: transactionParams.amount,
            currency: transactionParams.currency,
            balance: Math.floor(newBalance * 1e2)
        }
        return sendSuccessMessage2Client(ctx, 200, result)
        
    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
    //@TODO
}

async function betDiscard(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        console.log(checkKey)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
    } catch (error) {
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
    //@TODO
}

async function betRollback(ctx) {
    let params = ctx.request.body
    let jwtToken = params.payload
    try {
        let checkKey = common.verifyUserToken(jwtToken)
        if (!checkKey)  return sendErrorMessage2Client(ctx, 403, 1001)
        let datas = checkKey.payload
        let transactionParams = {
            addr: datas.transaction.ext_player_id,
            transactionId: datas.transaction.id,
            betTransactionId: datas.bet_transaction_id,
            betslipId: datas.transaction.betslip_id,
            ts: Math.floor(datas.transaction.timestamp * 1000),
            reason: datas.reason || '',
            status: datas.transaction.status,
            amount: datas.transaction.amount * 1e4,
            action: datas.transaction.operation,
            currency: datas.transaction.currency
        }
        console.log(transactionParams.addr, 'bet rollback@', transactionParams.transactionId, 'betId ===>', transactionParams.betTransactionId)
        let transaction = await userinfo.getTransactionByIdAndStatus(datas.bet_transaction_id, 50)
        if (_.isEmpty(transaction) || transaction[0].addr != transactionParams.addr) {
            return sendErrorMessage2Client(ctx, 400, 2003)
        }

        // 只有赢了的订单会取消, 其他情况的取消, 都是调用的refund
        if (transaction[0].status != tranStatus.win) {
            return sendErrorMessage2Client(ctx, 400, 2004)
        }

        let conn = null
        try {
            conn = await db.getConnection()
            if (conn == null) {
                return await sendErrorMessage2Client(ctx, 403, 204)
            }
            conn.beginTransaction()
            await userinfo.userRollBack(transactionParams, conn)
            conn.commit()
        } catch (error) {
            console.log('======================rollback=======================')
            logger.info(error)
            if (conn) conn.rollback()
            if (conn) conn.release()
            return await sendErrorMessage2Client(ctx, 400, 2004)
        } finally {
            if (conn) conn.release()
        }

        let newBalance = await userinfo.getUserBalance(transactionParams.addr, transactionParams.currency)
        let result = {
            id: datas.transaction.id,
            ext_transaction_id: datas.transaction.id,
            parent_transaction_id: datas.bet_transaction_id,
            user_id: transactionParams.addr,
            operation: transactionParams.action,
            amount: transactionParams.amount,
            currency: transactionParams.currency,
            balance: Math.floor(newBalance * 1e2)
        }
        return sendSuccessMessage2Client(ctx, 200, result)
        
    } catch (error) {
        console.log(error)
        return sendErrorMessage2Client(ctx, 403, 1001)
    }
}

module.exports = {
    ping,
    identify,
    betMake,
    betCommit,
    betSettlement,
    betRefund,
    betWin,
    betCancel,
    betDiscard,
    betRollback,
}