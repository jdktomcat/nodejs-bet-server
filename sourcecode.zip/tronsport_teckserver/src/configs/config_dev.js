const fs = require('fs');
const path = require('path');
let config = {
    env: 'dev',
    debug: false,
    app: {
        http_port : 9015,
        websocket_port: 9012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志,
        withdrawMaxTimes : 100,   //每天最大提取次数
        withdrawMaxAmount: 1000000000000,   // 每次最大提取数量
        randomSalt : 'hi,can-you-hear-me?',
        RankInitTs : 1555646400,
        rankRate : [
            47.887,
            23.943,
            11.972,
            5.986,
            2.993,
            1.496,
            1.197,
            0.958,
            0.766,
            0.613,
            0.490,
            0.392,
            0.314,
            0.251,
            0.201,
            0.161,
            0.129,
            0.103,
            0.082,
            0.066,
        ]
    },
    tranStatus : {
        bet: 0, //下注
        refund: 10, // 退款
        cancel: 20, // cancel, 之后不能在有其他操作
        settle: 30, // 完成   之后可以回滚
        rollback: 40, // 回滚  之后可以输赢
        win: 50,    // win    之后回滚操作
        lost: 51
    },
    mysqlConfig: {
        db_host: '192.169.80.102',
        db_port: '3306',
        db_name: 'test_tronb_live',
        db_user: 'root',
        db_pwd: '',
        connectionLimit : 5,
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        privateKey : '',

        withdrawAddr : '413a01c8450e55454ece8ab75f25494a9aa8391786',
        livePoolAddr : '416dd58ffa37007d861f5d5455b21c273f15fa9f69',
        rankwardAddr : '416dd58ffa37007d861f5d5455b21c273f15fa9f69',

        masterFullNode : 'https://api.trongrid.io',
        masterSolidityNode : 'https://api.trongrid.io',
        masterEventNode : 'https://api.trongrid.io',
        
        slaveFullNode : 'https://api.trongrid.io',
        slaveSolidityNode : 'https://api.trongrid.io',
        slaveEventNode : 'https://api.trongrid.io',
    },
    bettech : {
        publicKey : `-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvetrMOTA9BlWTUFb6WeJ
kjKAgaAfmmlzDZuO3tkKtr6cztZerzMU0ElIDS6VUme2bvHaASca1rBeQ6QygqIu
xkLDheSrvcbOEkfjdCWCfmlwBI6JybU7Bk94/z7ooVkLqBmOZ71m9ti5RWfD2Be8
XGeSUQGNn7TW1KiQo2bLLFp8hXezNnnMyeos6rIMwSIqcDIhYu9WsES7ClpMQ12j
QpIePocTbz388j+AezAADZh7w6CqdzVhAFvgEm3LUbbJu9jbfE/mWA0xRG1O2hXU
R9+bka6TuJG+CNZFEtF7VfGtMPMXBNe7IYVXfZ9CGOVCJQeKqIMNqUcYdE5wcpMo
I7eJeo+QAgcnyoP/1CFw/emRjInwO7m6lki4u7mT9RJONzE2ZmNrZr+YvVJo8W2W
KVs2n2+6o4NAybzI2kKTQoHaHD0u3q4lJRXmc5RoBX/tWlXCHms+uwM39YuxC8c1
Gv6U2qJZAfOqieJaq/qQdtql6L1H//d0n0p6nOJrwrf0VHY0sD6NJgTyQSd2EOtw
hcgT20o+1hRfiIXFMJP5j6fAnTl0y+7+5f74XtBOHcb4wva0uHCZNdVf+vuj22ce
ReYpcXq/3g5f8aKjXh9kbTczLyqMtqMbNN0h+FQn7Y9i5rk96nWZB2vg346NcyMN
2N7tcwi1WdJ62RULsL40x2UCAwEAAQ==
-----END PUBLIC KEY-----`,
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
} else {
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
