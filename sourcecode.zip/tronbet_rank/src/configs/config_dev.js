//仅根据开发环境覆盖相应字段即可
const path = require('path');
let config_dev = {
    env: 'development',//开发环境设为development
    debug: true,//开发环境设为true
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true //开启日志
    },
    mysqlConfig: {
        // db_host: '127.0.0.1',
        // db_port: '3306',
        // db_name: 'tron_bet_dice_test',
        // db_user: 'root',
        // db_pwd: '!@Q3wa$ESZ' //!@Q3wa$ESZ //
        db_host: '192.169.80.66',
        db_port: '3306',
        db_name: 'tron_bet_wzc',
        db_user: 'root',
        db_pwd: '' //!@Q3wa$ESZ //
    },
    tronConfig: {
        url_full: 'http://10.4.24.126:8090',
        url_solidity: 'http://10.4.24.126:8091',
        url_event: 'https://api.trongrid.io/',
        http_timeout: 5000,//ms
        defaultPk: '' //TAHAyhFkRz37o6mYepBtikrrnCNETEFtW5
    },
    award: {
        anteAddr: '4119727964e69634d77196fa41fa53fd9798e85a1b', //测试ANTE合约 4119727964e69634d77196fa41fa53fd9798e85a1b

        // TRX_RANK: [4, 3, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        // ANTE_RANK: [1],

        TRX_RANK: [0.5, 0.25, 0.125, 0.0625, 0.0313, 0.0156, 0.0078, 0.0039, 0.0020, 0.001],
        TRX_RANK_BASIC: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        ANTE_RANK: [1, 1, 1],

        RANK_SHOW_COUNT: 20,
        RANK_DURATION: 3 * 60 * 1000,//每轮排名持续时间(ms)
        SCAN_INTERVAL: 10000, //扫描间隔(ms)
        BEGIN_TS: 1546486440000,//开始时间戳(ms) 2019/1/3 11:15:00
    }
}

module.exports = config_dev;