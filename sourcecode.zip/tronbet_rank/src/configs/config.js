const fs = require('fs');
const path = require('path');
let config = {
    env: 'production',
    debug: false,
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true //开启日志
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_wzc',
        db_user: 'root',
        db_pwd: '' //!@Q3wa$ESZ //
    },
    tronConfig: {
        url_full: 'http://192.169.81.142:8090',
        url_solidity: 'http://192.169.81.142:8091',
        url_event: 'https://api.trongrid.io/',
        http_timeout: 5000,//ms
        defaultPk: '' //TPXEzZdh59rNGpa63upZu8mXfWChZbcKdk
    },
    award: {
        anteAddr: '411a44e676d4864660d984f6d1f4eb06d0f5cc5208', //正式ANTE合约 411a44e676d4864660d984f6d1f4eb06d0f5cc5208
        // TRX_RANK: [0.5, 0.25, 0.125, 0.0625, 0.0313, 0.0156, 0.0078, 0.0039, 0.0020, 0.001],
        // TRX_RANK_BASIC: [4000, 2000, 1000, 500, 250, 125, 62, 31, 15, 7],
        // ANTE_RANK: [240, 120, 40],
        // TRX_RANK: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        // TRX_RANK_BASIC: [8000, 4000, 2000, 1000, 500, 250, 125, 62, 31, 15],
        // ANTE_RANK: [0, 0, 0],
        TRX_RANK: [0.5, 0.25, 0.125, 0.0625, 0.0313, 0.0156, 0.0078, 0.0039, 0.0020, 0.001],
        TRX_RANK_BASIC: [1000, 500, 250, 125, 62, 31, 15, 7, 3, 1],
        ANTE_RANK: [0, 0, 0],

        RANK_SHOW_COUNT: 20,
        RANK_DURATION: 1 * 60 * 60 * 1000,//每轮排名持续时间(ms)
        SCAN_INTERVAL: 30000, //扫描间隔(ms)
        BEGIN_TS: 1546488000000,//开始时间戳(ms) 2019/1/3 12:00:00
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
