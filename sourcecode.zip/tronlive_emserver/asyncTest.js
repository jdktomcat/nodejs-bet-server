
async function otherPrint() {
    let timer = setInterval(() => {
        console.log('in other')
    }, 1000)
}

async function main() {
    otherPrint()
    console.log('---------------')
}

main()