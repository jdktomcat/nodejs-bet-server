const fs = require('fs');
const path = require('path');
let config = {
    env: 'dev',
    debug: false,
    app: {
        http_port : 9020,
        websocket_port: 9012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志,
        withdrawMaxTimes : 100,   //每天最大提取次数
        withdrawMaxAmount: 1000000000000,   // 每次最大提取数量
        randomSalt : 'hi,can-you-hear-me?',
    },
    mysqlConfig: {
        db_host: 'localhost',
        db_port: '3306',
        db_name: 'tronbet_poker_log',
        db_user: 'root',
        db_pwd: '',
        connectionLimit : 20,
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    mongoConfig: {
        host: '127.0.0.1',
        port: 27017,
        db: 'tronbet_poker_data',
        user: 'tbpoker',
        pwd: 'tronbetpoker2019'
    },
    tronConfig: {
        jackpotAddr : '415ae207ff9d5d95b9e0b4fe50f480508046a43595',
        masterFullNode : 'http://192.169.81.106:8090',
        masterSolidityNode : 'http://192.169.81.106:8091',
        masterEventNode : 'https://api.trongrid.io',
        
        slaveFullNode : 'https://api.trongrid.io',
        slaveSolidityNode : 'https://api.trongrid.io',
        slaveEventNode : 'https://api.trongrid.io',
    },
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
} else {
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
