const full = require('./scanFull')
const solidity = require('./scanSolidity')
