const db = require('./db')


const exec = require('child_process').exec;

async function queryGameStatus() {
    let res = await db.query("select max(ts) cnt from tron_bet_admin.moon_round_info")

    let now = new Date().getTime()

    

    let last = res[0].cnt || now

    console.log(now - last)
    try {
        if ((now - last) >= 10 * 60000) {
            console.log('--------------------')
            exec("pm2 reload 29", function (error, stdout, stderr) {
                if (error) {
                    console.log(error.stack)
                    console.log('Error code: ' + error.code)
                } else {
                    console.log('Error code: ' + stdout)
                }
            })
            console.log('-----------', now - last)
            await sleep(500000)
        } 
    } catch (error) {
        await sleep(10000)
    }

}


function sleep(time = 0) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve();
        }, time);
    })
}

async function main() {
    let timer = setInterval(queryGameStatus, 8 * 60000)
}


main()