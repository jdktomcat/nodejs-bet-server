#!/bin/bash

PROJECT_PATH="/data/tronbet_svn/tronbet"
logFile='./logs/run.log'
function help(){
    echo "cmd -p projectname -c start|reload|stop|status|rollback [-u -w -i]"
    echo "-u to update svn code"
    echo "-w to update svn config file to local project"
    echo "-i to run npm install in project"
    echo "avilable project names :"
    echo "`ls $PROJECT_PATH`"
}

whoRun=`whoami`
# if [ -f "./logs" ]; then
#     mkdir ./logs
# fi
# echo "`date '+%Y%m%d-%H%M%S'` $whoRun  run : $*" >> $logFile
updateCode=0
npmInstall=0
withUpdateConfig=0
projectName=''
while getopts "p:c:uiw" arg #选项后面的冒号表示该选项需要参数
do
    case $arg in
        p)
            projectName=$OPTARG
            ;;
        c)
            command=$OPTARG
            ;;
        u)
            echo "u"
            updateCode=1
            ;;
        i)
            echo "i"
            npmInstall=1
            ;;
        w)
            echo "w"
            withUpdateConfig=1
            ;;
        *)  #当有不认识的选项的时候arg为?
            help
            exit 1
            ;;
        esac
done

if [ "$projectName" = "" ];then
    help
    exit 2
fi

if [ "$command" = "" ];then
    help
    exit 3
fi

curl http://localhost:10881/cmd/$projectName/$command/$updateCode/$npmInstall/$withUpdateConfig/$whoRun