#!/bin/bash

SVN_PATH="/data/tronbet_svn/tronbet"
PROJECT_PATH="/data/tronbet_project"

function updateCode() {
    cd $SVN_PATH
    svn update
}

function backupOldCode() {
    projectName=$1
    # cd $PROJECT_PATH
    # if [ -f "./backup/${projectName}_last_backup.tar" ]; then
    #     mv ./backup/${projectName}_last_backup.tar  ./backup/${projectName}_`date '+%Y%m%d-%H%M%S'`_backup.tar
    # fi

    # if [ -d "$PROJECT_PATH/${projectName}" ]; then
    #     echo 'project ${projectName} start to backup'
    #     tar cf ./backup/${projectName}_last_backup.tar ${projectName}
    # else
    #     echo 'project ${projectName} not found, backup skip!!'
    # fi

    # if [ -f "./backup/${projectName}_last_backup.tar" ]; then
    #     echo "backup ${projectName} success!!"
    # fi
    echo 'do nothing'
}

function deployCodeWithConf() {
    projectName=$1
    echo "start to deploy $projectName"

    chmod -R 755 $PROJECT_PATH/$projectName/src/config*
    cp -prf /data/tronbet_svn/tronbet/$projectName/* $PROJECT_PATH/$projectName/.
    echo "deploy $projectName end"
}

function deployCodeWothOutConf() {
    projectName=$1
    if [ ! -d "$PROJECT_PATH/backup/$projectName" ];then
        mkdir -p $PROJECT_PATH/backup/$projectName
    fi
    cp -prf $PROJECT_PATH/$projectName/src/config*  $PROJECT_PATH/backup/$projectName/.
    cp -prf /data/tronbet_svn/tronbet/$projectName/* $PROJECT_PATH/$projectName/.
    cp -prf $PROJECT_PATH/backup/$projectName/config* $PROJECT_PATH/$projectName/src/
}

function rollback() {
    projectName=$1
    cd $PROJECT_PATH
    if [ -f "./backup/${projectName}_last_backup.tar" ]; then
        echo "echo rollback ${projectName}_last_backup.tar"
        mv ./backup/${projectName}_last_backup.tar  ./
        tar xf ${projectName}_last_backup.tar
    else 
        echo "WTF, NO backup files, please check"
    fi
}

function installModules() {
    echo "try to run npm install"
    projectName=$1
    cd $PROJECT_PATH/$projectName
    npm install
}

function restartService() {
    projectName=$1
    echo "restart $projectName"
    serviceInfo=`pm2 show $projectName| grep $projectName`
    if [ "$serviceInfo" = "" ]; then
        echo "service $projectName not exist, try to start new one"
        cd $PROJECT_PATH/$projectName
        dos2unix ./run.sh
        pm2 start run.sh -n $projectName -o /data/logs/$projectName.out -e /data/logs/$projectName.err
    else
        echo "reload $projectName"
        pm2 reload $projectName
    fi
}

function stopService() {
    projectName=$1
    echo "stop $projectName"
    serviceInfo=`pm2 show $projectName| grep $PROJECT_PATH`
    if [ "$serviceInfo" = "" ]; then
        echo "service $projectName not exist, try to start new one"
    else
        echo "stop $projectName"
        pm2 stop $projectName
    fi
}

#有些需要编译的, 在这里特殊处理
function compile() {
    projectName=$1
    if [ "$projectName" = "tronbet_backend"  -o  "$projectName" = "tronbet_profile" -o  "$projectName" = "tronbet_activity" ]; then
        echo 'tronbet_backend and tronbet_scan need to compile'
        cd $PROJECT_PATH/$projectName
        npm run compile 1> /dev/null 2>&1
        cd -
    fi
}


function main() {

    #获取参数, 去除尾部空格
   
    argUpdateCode=0
    agrNpmInstall=0
    argWithUpdateConfig=0
    projectName=''
    while getopts "p:c:uiwl:" arg #选项后面的冒号表示该选项需要参数
    do
        case $arg in
            c)
                argCmd=$OPTARG
                ;;
            u)
                echo "u"
                argUpdateCode=1
                ;;
            p)
                projectName=$OPTARG
                ;;
            i)
                echo "i"
                agrNpmInstall=1
                ;;
            w)
                echo "w"
                argWithUpdateConfig=1
                ;;
            l)
                echo "`date '+%Y-%m-%d %H:%M:%S'` $OPTARG runs $*" >> '/data/logs/runDeploy.log'
                ;;
            ?)  #当有不认识的选项的时候arg为?
                help
                ;;
            esac
    done

    echo  $argCmd, $argUpdateCode, $projectName, $argWithUpdateConfig, $agrNpmInstall

    #空目录检查
    if [ "X$projectName" = "X" ];then
        echo "args error"
        exit 1
    fi

    if [ ! -d "$SVN_PATH/$projectName" ]; then
        echo 'no such project, please check'
        exit 2
    fi

    if [ "$argCmd" = "" ];then
        echo '-c need args'
        exit 3
    fi

    #创建备份项目目录
    if [ ! -d "$PROJECT_PATH/backup" ]; then
        mkdir -p $PROJECT_PATH/backup
    fi

    #更新代码
    if [ "$argUpdateCode" = "1" ]; then
        updateCode
        #每次更新代码的时候, 需要将原来项目的代码备份
        backupOldCode "$projectName"
    fi

    #创建项目目录
    if [ ! -d "$PROJECT_PATH/$projectName" ]; then
        mkdir -p $PROJECT_PATH/$projectName
    fi

    if [ "$projectName" = "tronbet_web" ];then
        deployCodeWothOutConf "$projectName"
        echo "just deploy web content, end"
        exit 0
    fi

    if [ "$argWithUpdateConfig" = "1" ]; then
        deployCodeWithConf "$projectName"
    elif [ "$argWithUpdateConfig" = "0" ];then
        deployCodeWothOutConf "$projectName"
    else 
        echo 'project code not deploy, skip'
    fi

    # 安装依赖
    if [ "$agrNpmInstall" = "1" ];then
        installModules $projectName
    fi

    #是否有可执行程序
    if [ ! -f "$PROJECT_PATH/$projectName/run.sh" ]; then
        echo "no run.sh in $projectName, add it please"
        exit 10
    fi
    #执行命令
    echo $argCmd, '------------'
    case $argCmd in
        start)
            compile $projectName
            restartService $projectName
            ;;
        stop)
            stopService $projectName
            ;;
        reload)
            compile $projectName
            restartService $projectName
            ;;
        rollback)
            rollback "$projectName"
            ;;
        status)
            echo "`pm2 status`"
            ;;
        *)
            echo 'cmd not found, skip!!!'
            ;;
    esac
}

main $*
