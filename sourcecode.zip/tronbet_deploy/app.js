var http = require('http')
var url = require('url')
var exec = require('child_process').exec;


function ParseCmd(request, response) {
    response.writeHead(200, {'Content-Type': 'text/html'})

    let urls = url.parse(request.url)
    let pathname = urls.pathname
    if (pathname.startsWith('/cmd/')){
        let cmds = pathname.split('/')
        let [projectName, command, updateCode, npmInstall, withUpdateConfig, who] = [cmds[2], cmds[3], cmds[4], cmds[5], cmds[6], cmds[7]]
        let cmd =' -p ' + projectName + ' -c ' + command  + ' -l ' + who
        if (updateCode == '1' || updateCode == 1) {
            cmd += ' -u'
        }
        if (npmInstall == '1' || npmInstall == 1) {
            cmd += ' -i'
        }
        if (withUpdateConfig == '1' || withUpdateConfig == 1) {
            cmd += ' -w'
        }
        console.log(cmds)
        exec("bash ./deploy.sh " + cmd, function (error, stdout, stderr) {
            if (error) {
                console.log(error.stack)
                console.log('Error code: ' + error.code)
                response.end('args error')
            } else {
                response.end(stdout)
            }
        })
    } else if (pathname.startsWith('/info/')) {
        let cmd = pathname.substr(6,20)
        console.log(cmd)
        response.end(cmd)
    } else {
        response.end('ERROR CMD')
    }
}

var server = http.createServer(ParseCmd)

server.listen(10881);

console.log('Server is running at http://127.0.0.1:10881/')