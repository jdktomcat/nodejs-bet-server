//仅根据开发环境覆盖相应字段即可
const path = require('path');
let config_dev = {
    env: 'development',//开发环境设为development
    debug: true,//开发环境设为true
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志
        clearLog: true //启动日志清理
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_win', // ***
        db_user: 'root',
        db_pwd: '' // *** localhost=!@Q3wa$ESZ lan:123456 wan:
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 0,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        tron_url_full: 'https://api.trongrid.io', //***
        tron_url_solidity: 'https://api.trongrid.io',
        tron_url_event: 'https://api.trongrid.io/',

        back_tron_url_full: 'https://api.trongrid.io',
        back_tron_url_solidity: 'https://api.trongrid.io',
        back_tron_url_event: 'https://api.trongrid.io/',

        defaultPk: '', // ***

        beginBlockNumber: 10824200,
        //TVkNuE1BYxECWq85d8UR9zsv6WppBns9iH
        RANDOM_CONTRACT_ADDRESS: "41d8f55f2d6d3ee15785069337efa604c9f5e7cc38",
        //v3:TEEXEWrkMFKapSMJ6mErg39ELFKDqEs6w3 v2:TJZUQ7ZGPVy7pC2QXc5oZjr7wBgu6tX44e v1:TSpSmXD61aKrVJAeCKMUxJJdr5jHQo9XC2
        TRON_BET_CONTRACT_ADDRESS: ["41b8d1e2ee0e2db184a5096865751f75319b840956", "415e3c008d361c63940cbffbf22c04306d42eb1faf", "412ec5f63da00583085d4c2c5e8ec3c8d17bde5e28", "41668efd664ce820cd1298c017adb2189dfae0917a"], //用来判断dice事件版本
        DICE_DIVIDENDS_CONTRACT_ADDRESS: "4109ce88778ff1572f0e2e2dec26a9fb8975a1ffba", //dice分红合约地址
        WIN_DIVIDENDS_CONTRACT_ADDRESS: "41b357b7c9c27bda770da0fd705cd9d973d3122b67", //win分红合约地址
    }
}

module.exports = config_dev;
