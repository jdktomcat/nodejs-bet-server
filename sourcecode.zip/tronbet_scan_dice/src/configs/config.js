const fs = require('fs');
const path = require('path');
let config = {
    env: 'production',
    debug: false,
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志
        clearLog: true //启动日志清理
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_wzc', // ***
        db_user: 'root',
        db_pwd: '' // *** localhost=!@Q3wa$ESZ lan:123456 wan:
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 0,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        tron_url_full: 'http://192.169.81.106:8090',
        tron_url_solidity: 'http://192.169.81.106:8091',
        tron_url_event: 'https://api.trongrid.io/',

        back_tron_url_full: 'http://192.169.80.102:8090',
        back_tron_url_solidity: 'http://192.169.80.102:8091',
        back_tron_url_event: 'https://api.trongrid.io/',

        defaultPk: '', // ***

        beginBlockNumber: 10817771,
        //TVkNuE1BYxECWq85d8UR9zsv6WppBns9iH
        RANDOM_CONTRACT_ADDRESS_V2 : '4163f9f14d5319b7f8822e7771aea45b49e85bb35e',
        RANDOM_CONTRACT_ADDRESS: "4163f9f14d5319b7f8822e7771aea45b49e85bb35e",
        //v3:TEEXEWrkMFKapSMJ6mErg39ELFKDqEs6w3 v2:TJZUQ7ZGPVy7pC2QXc5oZjr7wBgu6tX44e v1:TSpSmXD61aKrVJAeCKMUxJJdr5jHQo9XC2
        TRON_BET_CONTRACT_ADDRESS: ["", "", "", "41e42d76d15b7ecd27a92cc9551738c2635c63b71c"],
        DICE_DIVIDENDS_CONTRACT_ADDRESS: "41b461e58a69c8fb8dec6e23888d5fcd743ab56938", //dice分红合约地址
        WIN_DIVIDENDS_CONTRACT_ADDRESS: "41479dfc899e9e8cfcc7adcf26dbdab49623f3b0a5", //win分红合约地址
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
