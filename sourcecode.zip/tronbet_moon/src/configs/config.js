const fs = require('fs');
const path = require('path');
let config = {
    env: 'production',
    debug: false,
    app: {
        websocket_port: 8012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true //开启日志
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_admin',
        db_user: 'root',
        db_pwd: '' //!@Q3wa$ESZ
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        node: {
            master: {
                // url_full: 'http://10.4.24.126:8090',
                // url_solidity: 'http://10.4.24.126:8091',
                url_full: 'http://192.169.80.102:8090',
                url_solidity: 'http://192.169.80.102:8091',
                url_event: 'https://api.trongrid.io/',
                defaultPk: ''
            },
            slave: {
                // url_full: 'http://192.169.81.142:8090',
                // url_solidity: 'http://192.169.81.142:8091',
                url_full: 'http://192.169.81.142:8090',
                url_solidity: 'http://192.169.81.142:8091',
                url_event: 'https://api.trongrid.io/',
                defaultPk: ''
            }
        },
        IGNORE_SOLIDITY_NODE_SCAN: true, //忽略检测静态节点状态
        SCAN_NODE_INTERVAL: 3100, //node 扫描间隔(ms)
        HTTP_TIME_OUT: 6300, //node http request 超时时间(ms)
    },
    moon: {
        orcAddr: '417df10519e630f46071ff0569494d03b83d8289ca', //随机数合约地址
        moonAddr: '41bdd85750b6774910ca5d12b0620ba318eb00154b', //订单合约地址
        logicAddr: '415ee4096bad59e4656447af5420e09ef35f1e94ec', //奖池合约地址

        APP_KEY: 'TRON_BET_MOON', //APP_KEY
        RANDOM_SALT_1: 'XfGNDsF0JInUDx!vUZjttXp4jP4dc^%f', //随机数盐1
        RANDOM_SALT_2: '7y1@&jJvvOk87qbttfJQ4UymhOVRI4kt', //随机数盐2
        RANDOM_SALT_3: '9N1#s1WFc01S^#P%', //随机数盐3

        READY_DURATION: 20000, //等待下注事件ms
        MAX_LOSE: 2000000, //每轮游戏最大赔付上限trx => 自动爆点
        MAX_BET: 20000, //单个玩家最大下注金额trx
        MAX_PAYOUT: 220000, //单个玩家最大赔付下注限制trx
        MAX_RATE: 9999, //最大爆点
        BROADCAST_INTERVAL_TS: 100, //广播间隔ms
        broadcast_player_info_when_action: true, //是否玩家进出推送完整玩家信息列表
        check_key: false, //开启玩家数据验证

        // ACTIVITY_START_TS : 1545360800000,//2018/12/21 12:0:0 ms //test
        ACTIVITY_START_TS: 1552881600000,//2019/3/18 12:0:0 ms
        ACTIVITY_END_TS: 1554091200000,//2019/4/1 12:0:0 ms

        task_bet: 100, //任务投注额要求
        task_2_val: 0, //任务2要求逃脱倍率
        task_5_val: 2, //任务5要求逃脱倍率
        task_8_val: 5, //任务8要求逃脱倍率
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
