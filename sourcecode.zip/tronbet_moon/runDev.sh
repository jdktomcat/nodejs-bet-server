#!/bin/sh
npm run dev