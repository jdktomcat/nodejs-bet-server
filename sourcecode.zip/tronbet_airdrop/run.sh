#!/bon/bash
npm run start