const fs = require('fs');
const path = require('path');
let config = {
    env: 'dev',
    debug: false,
    app: {
        http_port : 9011,
        websocket_port: 9012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志,
        withdrawMaxTimes : 100,   //每天最大提取次数
        withdrawMaxAmount: 1000000000000,   // 每次最大提取数量
        randomSalt : 'hi,can-you-hear-me?'
    },
    mysqlConfig: {
        db_host: '192.169.80.102',
        db_port: '3306',
        db_name: 'test_tronb_live',
        db_user: 'root',
        db_pwd: '',
        connectionLimit : 5,
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        startBlockNum : 8217400,
        privateKey : '',
        stakerAddr : '414c0fbc651c388f2f500043d95362e304e546c277',
        withdrawAddr : '413a01c8450e55454ece8ab75f25494a9aa8391786',
        livePoolAddr : '4177598e6256635f6020e91699a8665f62b4e93123',
        anteStkerAddr : '41b2b9efe94cc9f548c2ee1755b217606db7521dcd',

        masterFullNode : 'https://api.trongrid.io',
        masterSolidityNode : 'https://api.trongrid.io',
        masterEventNode : 'https://api.trongrid.io',
        
        slaveFullNode : 'https://api.trongrid.io',
        slaveSolidityNode : 'https://api.trongrid.io',
        slaveEventNode : 'https://api.trongrid.io',
    },
    softswiss : {
        BACKEND_URL : '',    // aggregator's url (our server)
        SCRIPT_URL : '',     // frontend service library location
        CASINO_URL  : '',    // casino api endpoint (your server)
        AUTH_TOKEN : '',     // token used to sign messages
        CASINO_ID : '',      // your casino's identifier
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
} else {
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
