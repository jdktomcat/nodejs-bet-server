const fs = require('fs');
const path = require('path');
let defaultPK = null;
try {
    defaultPK = require('/data/tronbet_project/config/privateKey').pk;
} catch (error) {
    console.info("using app pk");
    defaultPK = '';
}

let config = {
    env: 'production',
    debug: false,
    app: {
        http_port: 9011,
        websocket_port: 9012,
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志
        randomSalt : 'hi,can-you-hear-me?'
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_live',
        db_user: 'root',
        db_pwd: '', //!@Q3wa$ESZ
        connectionLimit: 10,
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
        startBlockNum: 8217400,
        privateKey: defaultPK,
        stakerAddr: '4182401794f58a8786995ba71bbcbefdd4041e07a1',
        withdrawAddr: '414f012a6d5ecc301ec577714bb1431ed7e6f3ba0c',
        livePoolAddr: '41ba01bef5a503d3404e62b426b7e4e4595fe14530',
        anteStkerAddr : '414f92846c191c774d761f3949f9794288b3b9a995',

        masterFullNode: 'http://192.169.81.106:8090',
        masterSolidityNode: 'http://192.169.81.106:8091',
        masterEventNode: 'https://api.trongrid.io',

        slaveFullNode: 'http://192.169.80.102:8090',
        slaveSolidityNode: 'http://192.169.80.102:8091',
        slaveEventNode: 'https://api.trongrid.io',
    },
    softswiss: {
        BACKEND_URL: '',    // aggregator's url (our server)
        SCRIPT_URL: '',     // frontend service library location
        CASINO_URL: '',    // casino api endpoint (your server)
        AUTH_TOKEN: '',     // token used to sign messages
        CASINO_ID: '',      // your casino's identifier
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
} else {
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
