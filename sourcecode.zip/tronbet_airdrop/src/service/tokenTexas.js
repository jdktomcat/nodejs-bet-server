/**
 * Texas Poker
 */

async function airdrop() {
   //  console.log('Texas Poker token airdrop coming soon')
}

module.exports = {
   airdrop,
}