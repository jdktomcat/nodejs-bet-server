const fs = require('fs');
const path = require('path');
let config = {
    env: 'production',
    debug: false,
    tronConfig: {
        url_full: 'http://192.169.81.106:8090', //https://api.trongrid.io https://super.guildchat.io
        url_solidity: 'http://192.169.81.106:8091', //https://api.trongrid.io https://solidity.guildchat.io
        url_event: 'https://api.trongrid.io',
        http_timeout: 5000, //node http request 超时时间(ms)
        defaultPk: '', //TEzkwVd7cpRfxUvJ3jtGgQcydAzu7FVLuK
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_wzc',
        db_user: 'root',
        db_pwd: '' //!@Q3wa$ESZ //
    },
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        reset_ts: 1547784000000, //2019/1/18 12:00
        reset_interval: 86400000, //ms 86400000=1天
        min_lv: 15, //15

        top_task_id: 9,
        tasks_config: {
            1: { need: 30, trx: 10 },
            2: { need: 30, trx: 10 },
            3: { need: 20, trx: 15 },
            4: { need: 20, trx: 15 },
            5: { need: 20, trx: 15 },
            6: { need: 10, trx: 15 },
            7: { need: 1, trx: 30 },
            8: { need: 5, trx: 25 },
            9: { need: 5, trx: 25 },
            10: { need: 4, trx: { 15: 20, 20: 32, 25: 44, 30: 56, 35: 68, 40: 80, 45: 92, 50: 104, 55: 116, 60: 128, 65: 140, 70: 152, 75: 164, 80: 176, 85: 188, 90: 200, 95: 212 } },
            11: { need: 7, trx: { 15: 30, 20: 48, 25: 66, 30: 84, 35: 102, 40: 120, 45: 138, 50: 156, 55: 174, 60: 192, 65: 210, 70: 228, 75: 246, 80: 264, 85: 282, 90: 300, 95: 318 } },
            12: { need: 9, trx: { 15: 50, 20: 80, 25: 110, 30: 140, 35: 170, 40: 200, 45: 230, 50: 260, 55: 290, 60: 320, 65: 350, 70: 380, 75: 410, 80: 440, 85: 470, 90: 500, 95: 530 } },
        },
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
