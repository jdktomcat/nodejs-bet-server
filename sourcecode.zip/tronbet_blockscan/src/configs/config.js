const fs = require('fs');
const path = require('path');
let config = {
    env: 'production',
    debug: false,
    startBlockNum : 10804727,
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志
        clearLog: true //启动日志清理
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_admin',
        db_user: 'root',
        db_pwd: ''
    },
    redisConfig: {
        host: '127.0.0.1',
        port: 6379,
        db: 1,
        pwd: 'tronbet_201811'
    },
    tronConfig: {
		tron_url_full: 'https://api.trongrid.io',
        tron_url_solidity: 'https://api.trongrid.io',
        tron_url_event: 'https://api.trongrid.io/',

        back_tron_url_full: 'https://super.guildchat.io',
        back_tron_url_solidity: 'https://solidity.guildchat.io',
        back_tron_url_event: 'https://api.trongrid.io/',

        defaultPk: '', // ***

        diceOrderAddr : '41e42d76d15b7ecd27a92cc9551738c2635c63b71c',
        wheel_oracle_addr : '41f1dd6a50563513b024a8c1a8257cadd66f42d16e',
        wheel_bet_addr : '41106841eb00cad39b90bf410fc52af8f73f2bbe2b',
        moon_oracle_addr : '417df10519e630f46071ff0569494d03b83d8289ca',
        moon_bet_addr : '41bdd85750b6774910ca5d12b0620ba318eb00154b',
        pvp_bet_addr : '4125fcfd3729801561b37f73189c98ab50341310c5',
        pvp_oracle_addr : '4150882bdd432f6d47a634a2c44b37f23ddb4115cf',
        pvp_logic_addr : '41a67fd02df7895a8bc70a0401db26ba0f2c3e28de',
        trc10_bet_addr : '411fee56b32884a49155b7b6137ec0f1ee657455d5',
        trc10_oracle_addr : '4110d718c22e8aa287bb8193aceaf3b90e66e90e0a',
    }
}

if (process.env.NODE_ENV === 'production' && fs.existsSync(__dirname + '/config.js')) { //生产环境
    console.log('>>>Use production config!');
} else if (process.env.NODE_ENV === 'test' && fs.existsSync(__dirname + '/config_test.js')) { //公网测试环境
    config = Object.assign(config, require('./config_test.js'));
    //console.log('>>>Use test config!');
} else if (process.env.NODE_ENV === 'lan' && fs.existsSync(__dirname + '/config_lan.js')) { //内网测试环境
    config = Object.assign(config, require('./config_lan.js'));
    //console.log('>>>Use lan config!');
} else if (process.env.NODE_ENV === 'development' && fs.existsSync(__dirname + '/config_dev.js')) { //开发环境
    config = Object.assign(config, require('./config_dev.js'));
    //console.log('>>>Use development config!');
} else {
    // throw new Error("Config file is lost !!!");
    config = Object.assign(config, require('./config_dev.js'));
}

module.exports = config;
