const scanDice = require('./scanDice')
const scanMoon = require('./scanMoon')
const scanRing = require('./scanRing')
const scanTrc10Dice = require('./scanTrc10Dice')

function main() {
    scanDice.main()
    scanMoon.main()
    scanRing.main()
    scanTrc10Dice.main()
}

main()