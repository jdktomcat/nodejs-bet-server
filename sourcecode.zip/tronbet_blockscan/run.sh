#!/bin/sh
node index.js
# node scanDice.js &
# node scanMoon.js &
# node scanRing.js &
# node scanTrc10Dice.js &
