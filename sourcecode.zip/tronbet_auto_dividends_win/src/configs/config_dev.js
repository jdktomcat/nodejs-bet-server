//仅根据开发环境覆盖相应字段即可
const path = require('path');
let config_dev = {
    env: 'development',//开发环境设为development
    debug: true,//开发环境设为true
    app: {
        logPath: path.resolve(__dirname, '../../logs'),
        log: true, //开启日志
        init_ts: 1545537600, //初始截止时间戳 2018/12/23 12:0:0 NEW DICE
        duration: 86400, //每轮有效时间（秒） 86400
        time_out: 1200, //超时时间（秒）
        dividends_addr: "41b357b7c9c27bda770da0fd705cd9d973d3122b67", //分红合约地址
        pool_addr: "41c059b61c309c575460761fc572d2dce6d602cc0f", //奖池合约地址
        min_pool_trx: 1, //最小分红奖池（单位TRX）
        min_interval_ts: 60, //发奖最小间隔时间(秒)
        pool_save_trx: 0, //WIN奖池保留0TRX
        test_trx: 10,//测试要发送的TRX数量 0:按实际奖池数量发送 ***
        ignore_round_in_db: 0, //忽略数据库中不存在的轮次 ***
    },
    tronConfig: {
        node: {
            master: {
                url_full: 'https://api.trongrid.io',
                url_solidity: 'https://api.trongrid.io',
                url_event: 'https://api.trongrid.io/',
                defaultPk: ''
            },
            slave: {
                url_full: 'https://api.trongrid.io',
                url_solidity: 'https://api.trongrid.io',
                url_event: 'https://api.trongrid.io/',
                defaultPk: ''
            }
        },
        IGNORE_SOLIDITY_NODE_SCAN: true, //忽略检测静态节点状态
        SCAN_NODE_INTERVAL: 3100, //node 扫描间隔(ms)
        HTTP_TIME_OUT: 15000, //node http request 超时时间(ms)
    },
    redisConfig: {
        host: '127.0.0.1', //192.169.80.66
        port: 6379,
        db: 0,
        pwd: 'tronbet_201811'
    },
    mysqlConfig: {
        db_host: '127.0.0.1',
        db_port: '3306',
        db_name: 'tron_bet_win', // ***
        db_user: 'root',
        db_pwd: '' // *** localhost=!@Q3wa$ESZ lan:123456 wan:
    },
    support_trc10_list: {
        //TESTTWO:TSnHCFwsJxChEsV4mNoEPfA7qpzLcXzGjt
        // BTT: { tokenID: 1002072, tokenName: "BTT", decimail: 0, save_token: 1, poolAddr: '41b869101e67668c8ca3ff65fe744275f4dc5a7157', awardPK: '54B730AB3B20B2A20E0BC5F00067B60395DBA549F9D319777BDD7C76B229BAFD' }
        //BTT_POOL_ADDR:TKnAG9zcXMwxuKKRwYXecJT9sBrRPhmtCW //acc:TBv7igM3eVRsd144ayw7X3ecxsAdMQfBne (合约要求最少提币额>100BTT)
        //save_token:合约中保留多少BTT不用于分红
        BTT: { tokenID: 1002000, tokenName: "BTT", testRound: 97, decimail: 6, save_token: 100, poolAddr: '416b9a653007e574fdbf1da4a3705399f222de7cf8', awardPK: '9053f12da788b539cedcfe4ed7dce4844364cd49764f76fa58ba2ad1b20b1ee3' }
    }
}

module.exports = config_dev;
